package com.dysy.demo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;

public class ChangePassword extends JFrame {

	private JPanel contentPane;//底层面板
	private JPasswordField oldMima;//原来的密码
	private JPasswordField newMima;//新密码
	private JPasswordField confirmMima;//确认新密码
	private JLabel sameMima;//提示第二次输入的密码是否相同

	/**
	 * 启动应用
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChangePassword frame = new ChangePassword();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * 创建修改密码的面板
	 */
	public ChangePassword() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(700,300, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		setContentPane(contentPane);
		
		JLabel oldMimaLabel = new JLabel("\u539F\u5BC6\u7801");//原密码标签
		oldMimaLabel.setFont(new Font("宋体", Font.PLAIN, 18));
		
		JLabel newMimaLabel = new JLabel("\u65B0\u7684\u5BC6\u7801");//新密码标签
		newMimaLabel.setFont(new Font("宋体", Font.PLAIN, 18));
		
		JLabel confirmMimaLabel = new JLabel("\u786E\u8BA4\u5BC6\u7801");//确认密码标签
		confirmMimaLabel.setFont(new Font("宋体", Font.PLAIN, 18));
		
		JButton confirmButton = new JButton("\u786E\u8BA4");//确认按钮
		confirmButton.setBackground(new Color(175, 238, 238));
		confirmButton.setBorderPainted(false);
		confirmButton.setFocusPainted(false);
		
		oldMima = new JPasswordField();
		oldMima.setFont(new Font("宋体", Font.PLAIN, 18));
		oldMima.setOpaque(false);
		
		newMima = new JPasswordField();
		newMima.setFont(new Font("宋体", Font.PLAIN, 18));
		newMima.setOpaque(false);
		
		confirmMima = new JPasswordField();
		confirmMima.setFont(new Font("宋体", Font.PLAIN, 18));
		confirmMima.setOpaque(false);
		
		sameMima = new JLabel("\u5BC6\u7801\u6709\u8BEF");
		sameMima.setForeground(Color.RED);
		sameMima.setVisible(false);
		
		JButton cancelButton = new JButton("\u53D6\u6D88");//取消按钮
		cancelButton.setBackground(new Color(245, 222, 179));
		cancelButton.setBorderPainted(false);
		cancelButton.setFocusPainted(false);
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
					.addGap(32)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(newMimaLabel)
						.addComponent(confirmMimaLabel)
						.addComponent(oldMimaLabel))
					.addGap(34)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(confirmButton)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(cancelButton))
						.addComponent(confirmMima, Alignment.TRAILING)
						.addComponent(newMima, Alignment.TRAILING)
						.addComponent(oldMima, GroupLayout.PREFERRED_SIZE, 193, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(sameMima)
					.addContainerGap(37, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(34)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(oldMima, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(oldMimaLabel))
					.addGap(26)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(newMima, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(newMimaLabel))
					.addGap(26)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(confirmMima, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(confirmMimaLabel)
						.addComponent(sameMima))
					.addPreferredGap(ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(confirmButton)
						.addComponent(cancelButton))
					.addGap(30))
		);
		oldMima.addKeyListener(new PasswordText());
		newMima.addKeyListener(new PasswordText());
		confirmMima.addKeyListener(new PasswordText());
		confirmButton.addActionListener(new confirmButtonHandler(oldMima,newMima,confirmMima));
		contentPane.setLayout(gl_contentPane);
	}
	
	/**
	 * 内部类，给密码框添加键盘事件，使密码框只能输入数字
	 */
	public class PasswordText extends KeyAdapter{
		public void keyTyped(KeyEvent e) {
			int key=e.getKeyChar();
			
			if((!(key >= KeyEvent.VK_0 && key <= KeyEvent.VK_9)) )
			{
				e.consume();
			}
		}
	}
	
	/**
	 * 给确认按钮添加事件处理
	 */
	public class confirmButtonHandler implements ActionListener{
		private JPasswordField oldMima;//原密码
		private JPasswordField newMima;//新密码
		private JPasswordField confirmMima;//确认密码
		private int sameChar = 0;//6位密码相同的个数
		
		/**
		 * @param oldMima
		 * @param newMima
		 * @param confirmMima
		 */
		public confirmButtonHandler(JPasswordField oldMima,JPasswordField newMima,JPasswordField confirmMima) {
			this.oldMima = oldMima;
			this.newMima = newMima;
			this.confirmMima = confirmMima;
		}
		
		/**
		 * 实现actionPerFORMED()方法
		 */
		public void actionPerformed(ActionEvent e) {
			for(int i = 0;i < InitMainFrame.list.size();i++)
			{
				if(InitUserLoginSurface.userAccount.equals(InitMainFrame.list.get(i).getAccount()))
				{
					StringBuilder password = new StringBuilder(InitMainFrame.list.get(i).getPassword());
					password.replace(InitMainFrame.list.get(i).getPassword().length()-1, InitMainFrame.list.get(i).getPassword().length(), "");
					if(new String(oldMima.getPassword()).equals(new String(password.toString())))
					{
						if(new String(newMima.getPassword()).equals(new String(confirmMima.getPassword())))
						{
							sameChar = 0;
							char[] mimaChar = new String(newMima.getPassword()).toCharArray();
							for(int j = 0;j < new String(newMima.getPassword()).length();j++)
							{
								sameMima.setVisible(false);
								if(mimaChar[j] == mimaChar[0])
									sameChar++;
							}
							System.out.println(sameChar);
							if(new String(newMima.getPassword()).equals(new String(oldMima.getPassword())) || new String(newMima.getPassword()).length() != 6 || sameChar % 6 == 0)
							{
								JOptionPane.showMessageDialog(null,"新密码不能与原密码相同，且必须为六位，六位密码也不能完全相同","提示消息",JOptionPane.ERROR_MESSAGE);
							}
							else
							{
								dispose();
								JOptionPane.showMessageDialog(null,"密码修改成功","提示消息",JOptionPane.INFORMATION_MESSAGE);
								InitMainFrame.list.get(i).setPassword(new String(newMima.getPassword())+"0");
							}
						}
						else
						{
							sameMima.setVisible(true);
						}
					}
					else
					{
						JOptionPane.showMessageDialog(null,"原密码错误","提示消息",JOptionPane.ERROR_MESSAGE);
					}
					break;
				}
			}
			InitMainFrame.userFile.saveFile(InitMainFrame.list);
		}
	}
}