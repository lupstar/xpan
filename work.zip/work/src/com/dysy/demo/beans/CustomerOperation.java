package com.dysy.demo.beans;

public interface CustomerOperation {

	 public void openAccount(Account account,Transaction transaction) throws Exception;
	 
	 public void deleteAccount(Account account) throws Exception;
	 
	 public void deleteAllAccount(Customer customer) throws Exception;
}
