package com.dysy.demo;
import java.awt.EventQueue;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class InitManagerSurface extends JFrame {

	private JPanel contentPane;//底层面板，创建管理员登录后的界面

	/**
	 * 启动应用
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InitManagerSurface frame = new InitManagerSurface();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * 创建管理员登录后的界面
	 */
	public InitManagerSurface() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(700, 300, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		setContentPane(contentPane);
		
		JButton newUserButton = new JButton("\u5F00   \u6237");//开户按钮
		newUserButton.setBackground(new Color(204, 204, 255));
		newUserButton.setBorderPainted(false);//设置边框不可见
		newUserButton.setFocusPainted(false);//点击按钮不出现边框
		//给开户按钮添加事件处理
		newUserButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NewUser newUser = new NewUser();
				newUser.setVisible(true);
			}
		});
		
		JButton deleUserButton = new JButton("\u6CE8\u9500\u8D26\u6237");//注销用户按钮
		deleUserButton.setBackground(new Color(255, 192, 203));
		deleUserButton.setBorderPainted(false);
		deleUserButton.setFocusPainted(false);
		//给销户按钮添加事件处理
		deleUserButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int accountExsist = 0;//判断用户是否存在，若存在，则加一
				String account = null;//保存JOptionPane中返回的字符串
				
				try {
					account = JOptionPane.showInputDialog(null, "输入账号", "注销", JOptionPane.INFORMATION_MESSAGE);
				} catch (HeadlessException e1) {
					
				}//防止点击取消或直接关闭时报错
				for(int i = 0;i < InitMainFrame.list.size();i++)
				{
					if(account != null && account.equals(InitMainFrame.list.get(i).getAccount()))
					{
						accountExsist++;
						InitMainFrame.list.remove(i);//注销用户
						i--;
						InitMainFrame.userFile.saveFile(InitMainFrame.list);
						JOptionPane.showMessageDialog(null, "注销成功", "提示消息", JOptionPane.INFORMATION_MESSAGE);
						break;
					}
				}
				if(accountExsist == 0)
				{
					JOptionPane.showMessageDialog(null, "用户不存在，注销失败", "提示消息", JOptionPane.ERROR_MESSAGE);
				}
				for(int i = 0;i < InitMainFrame.list.size();i++)
				{
					System.out.println(InitMainFrame.list.get(i));
				}
			}
		});
		
		JButton exitButton = new JButton("\u9000\u51FA");//退出按钮
		exitButton.setBackground(new Color(255, 239, 213));
		exitButton.setBorderPainted(false);//设置边框不可见
		exitButton.setFocusPainted(false);//点击按钮时不出现边框
		//给退出按钮添加事件处理
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				InitMainFrame mainFrame = new InitMainFrame();
				mainFrame.setVisible(true);
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(163)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
						.addComponent(exitButton, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(newUserButton, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(deleUserButton, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addContainerGap(166, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(54)
					.addComponent(newUserButton)
					.addGap(38)
					.addComponent(deleUserButton)
					.addGap(35)
					.addComponent(exitButton)
					.addContainerGap(35, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}

}