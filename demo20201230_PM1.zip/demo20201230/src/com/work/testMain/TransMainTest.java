/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.work.testMain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import javax.swing.JFrame;

import com.work.beans.Account;
import com.work.beans.Customer;
import com.work.beans.Transaction;
import com.work.beans.enums.AccountTypeEnum;
import com.work.beans.enums.TransTypeEnum;
import com.work.fileOperation.FileReaderAndWrite;
import com.work.panel.CustomerPanel;


/**
 *
 * @author Administrator
 */
public class TransMainTest extends JFrame{
    
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) throws Exception{
    	String exit = "";
    	Scanner sc = new Scanner(System.in);  

    	CustomerPanel frame = new CustomerPanel(null,null);
        frame.setVisible(true);
    	while(!"bye".equals(exit)) {
    		try {
    	    	System.out.println("请输入操作编码(open,del,delAll,withdrawal,deposit,transfer,card):");   
    	        String transType = sc.nextLine();
    	        switch(transType) {
    	        case "withdrawal":
    	        	TransMainTest.withdrawal(sc);
    	            break;
    	        case "deposit":
    	        	TransMainTest.deposit(sc);
    	            break;
    	        case "transfer":
    	        	TransMainTest.transfer(sc);
    	            break;
    	        case "card":
    	        	TransMainTest.card(sc);
    	            break;
    	        case "open":
    	        	TransMainTest.open(sc);
    	            break;
    	        case "del":
    	        	TransMainTest.delSingle(sc);
    	            break;
    	        case "delAll":
    	        	TransMainTest.delAll(sc);
    	            break;
    	        default:
    	            throw new Exception("操作不存在");
    	        }
    	        
    	        frame.dispose();
    	        frame = new CustomerPanel(null,null);
    	        frame.setVisible(true);
    		}catch (Exception e) {
				e.printStackTrace();
			}
    		System.out.println("结束请输入bye，继续请按enter:");   
    		exit = sc.nextLine();  
    	}
    }
    
    @SuppressWarnings("unused")
	public static void open(Scanner sc) throws Exception {
   	 	System.out.println("输入开户客户ID:");   
   	 	String custId = sc.nextLine();  
    	System.out.println("输入账户类型(Credit,Debit,Savings):");   
    	String accType = sc.nextLine();  
    	System.out.println("输入开户金额:");  
    	String openAmount = sc.nextLine();  
    	
    	List<Customer> customers = new ArrayList<>();;
        Transaction trans = null;
        
        AccountTypeEnum accountType = null;
        for(AccountTypeEnum accountTypeEnum:Arrays.asList(AccountTypeEnum.values())) {
    		if(accountTypeEnum.getAccountType().equals(accType)) {
    			accountType = accountTypeEnum;
    		}
    	}
        if(accountType==null) {
    		throw new Exception("账户类型不存在");
        }
        
        Customer operCustomer = null;
        FileReaderAndWrite.loadData(customers);
        if(customers!=null&&customers.size()>0){
            for(Customer customer:customers){
            	if(customer.getCustId().toString().equals(custId)) {
            		operCustomer = customer;
            	}
            }
        }
        if(operCustomer==null) {
        	throw new Exception("客户不存在");
        }
        
        operCustomer.openAccount(accountType, openAmount==null||"".equals(openAmount)?BigDecimal.ZERO:new BigDecimal(openAmount));
    }
    
    public static void delSingle(Scanner sc) throws Exception {
    	System.out.println("输入注销账号:");   
   	 	String accountNo = sc.nextLine();  
    	
    	List<Customer> customers = new ArrayList<>();;
    	Customer operCustomer = new Customer();
    	Account operAccount = null;
        FileReaderAndWrite.loadData(customers);
        if(customers!=null&&customers.size()>0){
            for(Customer customer:customers){
            	for(Account account:customer.getAccountList()) {
            		if(account.getAccountNumber().equals(accountNo)) {
            			operCustomer = customer;
            			operAccount = account;
            		}
            	}
            }
        }
        operCustomer.deleteAccount(operAccount);
    }
    
	public static  void delAll(Scanner sc) throws Exception {
    	System.out.println("输入注销所有账号的客户ID:");   
   	 	String custId = sc.nextLine();  
   	 	
    	Customer customer = new Customer(Long.valueOf(custId));
    	customer.deleteAllAccount();
    }
    
    @SuppressWarnings("unused")
	public static  void withdrawal(Scanner sc) throws Exception {
    	System.out.println("输入交易账号:");   
   	 	String accountNo = sc.nextLine(); 
   	 	System.out.println("输入交易金额:");   
	 	String amount = sc.nextLine(); 
    	
    	List<Customer> customers = new ArrayList<>();;
    	Customer operCustomer = null;
    	Account operAccount = null;
        FileReaderAndWrite.loadData(customers);
        if(customers!=null&&customers.size()>0){
            for(Customer customer:customers){
            	for(Account account:customer.getAccountList()) {
            		if(account.getAccountNumber().equals(accountNo)) {
            			operCustomer = customer;
            			operAccount = account;
            		}
            	}
            }
        }
        if(operAccount==null) {
        	throw new Exception("账号不存在");
        }
        Transaction transaction = new Transaction(TransTypeEnum.withdrawal, new BigDecimal(amount));
        operAccount.withdralAccount(transaction);
    }
    
    @SuppressWarnings("unused")
	public static  void deposit(Scanner sc) throws Exception {
    	System.out.println("输入交易账号:");   
   	 	String accountNo = sc.nextLine(); 
   	 	System.out.println("输入交易金额:");   
	 	String amount = sc.nextLine(); 
    	
    	List<Customer> customers = new ArrayList<>();;
    	Customer operCustomer = null;
    	Account operAccount = null;
        FileReaderAndWrite.loadData(customers);
        if(customers!=null&&customers.size()>0){
            for(Customer customer:customers){
            	for(Account account:customer.getAccountList()) {
            		if(account.getAccountNumber().equals(accountNo)) {
            			operCustomer = customer;
            			operAccount = account;
            		}
            	}
            }
        }
        if(operAccount==null) {
        	throw new Exception("账号不存在");
        }
        Transaction transaction = new Transaction(TransTypeEnum.deposit, new BigDecimal(amount));
        operAccount.depositAccount(transaction);
    }
    
    @SuppressWarnings("unused")
	public static  void transfer(Scanner sc) throws Exception {
    	System.out.println("输入交易账号:");   
   	 	String accountNo = sc.nextLine(); 
   	 	System.out.println("输入转账账号:");   
	 	String transAccountNo = sc.nextLine(); 
   	 	System.out.println("输入交易金额:");   
	 	String amount = sc.nextLine(); 
    	
    	List<Customer> customers = new ArrayList<>();;
    	Customer operCustomer = null;
    	Account operAccount = null;
        FileReaderAndWrite.loadData(customers);
        if(customers!=null&&customers.size()>0){
            for(Customer customer:customers){
            	for(Account account:customer.getAccountList()) {
            		if(account.getAccountNumber().equals(accountNo)) {
            			operCustomer = customer;
            			operAccount = account;
            		}
            	}
            }
        }
        if(operAccount==null) {
        	throw new Exception("账号不存在");
        }
        Transaction transaction = new Transaction(TransTypeEnum.transfer, new BigDecimal(amount));
        operAccount.transferAccount(transaction, transAccountNo);
    }
    
    @SuppressWarnings("unused")
	public static  void card(Scanner sc) throws Exception {
    	System.out.println("输入交易账号:");   
   	 	String accountNo = sc.nextLine(); 
   	 	System.out.println("输入交易金额:");   
	 	String amount = sc.nextLine(); 
    	
    	List<Customer> customers = new ArrayList<>();;
    	Customer operCustomer = null;
    	Account operAccount = null;
        FileReaderAndWrite.loadData(customers);
        if(customers!=null&&customers.size()>0){
            for(Customer customer:customers){
            	for(Account account:customer.getAccountList()) {
            		if(account.getAccountNumber().equals(accountNo)) {
            			operCustomer = customer;
            			operAccount = account;
            		}
            	}
            }
        }
        if(operAccount==null) {
        	throw new Exception("账号不存在");
        }
        Transaction transaction = new Transaction(TransTypeEnum.card, new BigDecimal(amount));
        operAccount.useCard(transaction);
    }
    
}
