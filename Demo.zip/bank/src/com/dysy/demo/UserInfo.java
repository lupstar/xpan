package com.dysy.demo;
import java.io.Serializable;

public class UserInfo implements Serializable{
	private String account;//卡号
	private String password;//密码
	private long money;//余额
	
	/**
	 * @return account
	 */
	public String getAccount() {
		return account;
	}
	
	/**
	 * @param account
	 */
	public void setAccount(String account) {
		this.account = account;
	}
	
	/**
	 * @return password
	 */
	public String getPassword() {
		return password;
	}
	
	/**
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
	/**
	 * @return money
	 */
	public long getMoney() {
		return money;
	}
	
	/**
	 * @param money
	 */
	public void setMoney(long money) {
		this.money = money;
	}
	
	public UserInfo() {
		
	}
	
	
	/**
	 * @param account
	 * @param password
	 * @param money
	 */
	public UserInfo(String account,String password,long money) {
		this.account = account;
		this.password = password;
		this.money = money;
	}
	
	/**
	 * 重写toString()方法,打印用户的部分信息
	 */
	public String toString() {
		String encryptedAccount = new StringBuilder(account).replace(account.length()/4,account.length()-(account.length()/4),"****").toString();//加密账号
		String encryptedPassword = new StringBuilder(password).replace(password.length()/4,password.length()-(password.length()/4),"****").toString();//加密密码
		return "卡号:"+encryptedAccount+"  密码:"+encryptedPassword+"  余额:"+money;
	}
	

}