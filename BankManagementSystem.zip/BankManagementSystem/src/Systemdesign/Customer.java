package Systemdesign;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import base.CustomerOperation;
import systemdesignenum.AccountTypeEnum;
import systemdesignenum.TransTypeEnum;
import fileOperation.FileReadAndWrite;

public class Customer implements CustomerOperation {
    //fields
    private String custName;

    private Long custId;

    private LocalDate birthDate;

    private List<Account> accountList;
    
    //constructors
    public Customer(Long custId) {
        this.custId = custId;
    }

    public Customer(String custName, Long custId, LocalDate birthDate, List<Account> accountList) {
        this.custName = custName;
        this.custId = custId;
        this.birthDate = birthDate;
        this.accountList = accountList;
    }
    
    public Customer() {
        // TODO Auto-generated constructor stub
    }
    
    //getters
    public String getCustName() {
        return custName;
    }

    public Long getCustId() {
        return custId;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public List<Account> getAccountList() {
        return accountList;
    }

    /**
     * 校验：一个客户最多只能拥有5个银行账户
     *
     * @param accountList
     * @throws Exception
     */
    //This a method to check valid accunt number of a customer
    private void checkAccountNumber() throws Exception {
        if (accountList.size() == 5) {
            throw new Exception("You can only have up to five (5) bank accounts in total");
        }
    }

    /**
     * 校验：已经有至少一个信用账户的情况下，只能开立一个储蓄账户
     *
     * @param account
     * @throws Exception
     */
    //This is a method used to check the account type customers can open 
    private void checkOpenAccountType(AccountTypeEnum accountTypeEnum) throws Exception {
        int savingAccountCount = 0;
        boolean existCreditAccount = false;
        for (Account existAccount : accountList) {
            if (AccountTypeEnum.credit.equals(existAccount.getAccountType())) {
                existCreditAccount = true;
            } else if (AccountTypeEnum.savings.equals(existAccount.getAccountType())) {
                savingAccountCount++;
            }
        }
        if (accountTypeEnum.getAccountType().equals(AccountTypeEnum.savings.getAccountType())
                && existCreditAccount && savingAccountCount > 0) {
            throw new Exception("You can only open a savings account if they already have at least one credit account.");
        }
    }

    /**
     * 校验：未成年人只能开立借方账户，未成年人是指开户时不满18(18)岁的客户
     *
     * @param account
     * @throws Exception
     */
    //This is a method used to check the valid age of the customer who wants to open an account
    private void checkAgePrinciple(AccountTypeEnum accountTypeEnum) throws Exception {
        boolean isJuveniles = LocalDate.now().compareTo(this.birthDate) <= 18;
        if (isJuveniles && !AccountTypeEnum.credit.getAccountType()
                .equals(accountTypeEnum.getAccountType())) {
            throw new Exception("Customers who are less than 18 years old including 18 can only open debit accounts ");
        }
    }
    //this is a method overrided from CustomerOperation.Customer can open three types of accounts: credit,debit,savings.
    @Override
    public void openAccount(AccountTypeEnum accountTypeEnum, BigDecimal openAmount) throws Exception {
        Account account = null;
        Transaction transaction = null;
        this.checkAccountNumber();
        this.checkOpenAccountType(accountTypeEnum);
        this.checkAgePrinciple(accountTypeEnum);

        switch (accountTypeEnum.getAccountType()) {
            case "Credit":
                account = new CreditAccount(KeyGenerator.getIbanKey(), BigDecimal.ZERO, KeyGenerator.getCardIdKey());
                break;
            case "Debit":
                account = new DebitAccount(KeyGenerator.getIbanKey(), BigDecimal.ZERO, KeyGenerator.getCardIdKey());
                break;
            case "Savings":
                account = new SavingsAccount(KeyGenerator.getIbanKey(), BigDecimal.ZERO, null);
                break;
        }
        //when an account is opened, the initial balance should be a non-negative number.
        if (openAmount != null) {
            if (openAmount.compareTo(BigDecimal.ZERO) > 0) {
                transaction = new Transaction(TransTypeEnum.deposit, openAmount);
            } else if (openAmount.compareTo(BigDecimal.ZERO) < 0) {
                throw new Exception("开户存款金额不能小于0:Accounts can only be opened with a non-negative initial balance.");
            }
        }
        
        //开户
        FileReadAndWrite.writeAccount(account, custId, null, "add");
        //The initial amount of opening an accunt would be kept in the new account
        if (account != null && transaction != null) {
            account.depositAccount(transaction);
        }
    }
    //this is a method when customer wants to delete an account ,and the condition is tbat the balance should be 0;
    @Override
    public void deleteAccount(Account account) throws Exception {
        account.queryCustomerByAccountNumber(account.getAccountNumber());
        if (account.getBalance().compareTo(BigDecimal.ZERO) != 0) {
            throw new Exception("You cannot delete the account because the balance is not zero");
        } else {
            //delete the account
            FileReadAndWrite.writeAccount(account, custId, null, "del");
        }

    }
    // this is a method to delete all accounts of a customer and the condition is that the balance should all be zero;
    @Override
    public void deleteAllAccount() throws Exception {
        Customer customer = this.queryCustomerByCustId(this.custId);
        List<Account> accounts = customer.getAccountList();
        for (Account account : accounts) {
            if (account.getBalance().compareTo(BigDecimal.ZERO) != 0) {
                throw new Exception("The accounts[" + account.getAccountNumber() + "]' balance is not zero, you cannot delete all accounts");
            }
        }
        //delete all accounts
        for (Account account : accounts) {
            FileReadAndWrite.writeAccount(account, custId, null, "del");
        }
    }
   //This is a method to query customers by customer ID
    public Customer queryCustomerByCustId(Long custId) throws Exception {
        // 
        List<Customer> customers = new ArrayList<>();
        FileReadAndWrite.loadData(customers);
        for (Customer customer : customers) {
            if (custId.compareTo(customer.getCustId()) == 0) {
                return customer;
            }
        }
        throw new Exception("Customer ID 【" + custId + "】is not exist ");
    }

}
