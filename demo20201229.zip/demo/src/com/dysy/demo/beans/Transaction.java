package com.dysy.demo.beans;

import java.math.BigDecimal;
import java.util.UUID;


public class Transaction {

    private String transId;
    private TransTypeEnum transType;
    //签名的数字值,可正可负
    private BigDecimal amount;
    
    public Transaction(TransTypeEnum transType,BigDecimal amount) {
    	this.transId = UUID.randomUUID().toString().replace("-", "");
    	this.transType = transType;
    	this.amount = amount;
    }
    
    public Transaction(String transId,TransTypeEnum transType,BigDecimal amount) {
    	this.transId = transId;
    	this.transType = transType;
    	this.amount = amount;
    }

    public String getTransId() {
        return transId;
    }

    public TransTypeEnum getTransType() {
        return transType;
    }

    public BigDecimal getAmount() {
        return amount;
    }

}
