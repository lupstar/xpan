package com.dysy.demo.beans;


public enum AccountTypeEnum {

    credit("Credit","借方"),

    debit("Debit","贷方"),

    savings("Savings","储蓄");


    private String accountType;

    private String description;

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    AccountTypeEnum(String accountType, String description){
        this.accountType = accountType;
        this.description = description;
    }
}
