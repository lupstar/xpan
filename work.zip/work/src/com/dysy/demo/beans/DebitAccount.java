package com.dysy.demo.beans;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

public class DebitAccount extends Account {

	//信用卡属性
    private Long card;

    public Long getCard() {
        return card;
    }

    public void setCard(Long card) {
        this.card = card;
    }
    
    public String getAccountType() {
    	return AccountTypeEnum.debit.getAccountType();
    }
    
    public List<TransTypeEnum> getTransFunction() {
    	return Arrays.asList(TransTypeEnum.values());
    }
    
    /**
     * 借方账户不能有负余额，所以任何负金额的交易都需要检查它不会导致余额变为负。如果是这样，则必须拒绝该事务。
     */
    public boolean checkTransAmount(Transaction trans) {
    	if(this.getBalance().add(trans.getAmount()).compareTo(BigDecimal.ZERO)<0) {
    		return false;
    	}
    	return true;
    }

}
