/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainTest;

import com.dysy.demo.beans.Account;
import com.dysy.demo.beans.AccountTypeEnum;
import com.dysy.demo.beans.Customer;
import com.dysy.demo.beans.TransTypeEnum;
import com.dysy.demo.beans.Transaction;
import com.dysy.demo.dataload.FileReaderAndWrite;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author Administrator
 */
public class TransMainTest {
    
    public static void main(String[] args) throws Exception{
        //交易类型
        String transType = "";
        
        //开户参数
        Long openCustomerId = 111l;
        String openAccountType = "";
        //交易参数
        String accountNumber = "";
        //转账+transferAccNumber
        String transferAccNumber = "";
        
        BigDecimal amount = new BigDecimal( "");
        List<Customer> customers = null;
        Transaction trans = null;
        FileReaderAndWrite.loadData(customers);
        if(customers!=null&&customers.size()>0){
            for(Customer customer:customers){
                if("open".equals(transType)){
//                    customer.openAccount(openAccountType., amount);
                    
                }
                List<Account> accounts = customer.getAccountList();
                if(accounts!=null&&accounts.size()>0){
                    for(Account account:accounts){
                        if(account.getAccountNumber().equals(accountNumber)){
                            switch(transType){
                                case "C01":
                                    trans = new Transaction(TransTypeEnum.withdrawal,amount);
                                    account.withdralAccount(trans);
                                    break;
                                case "C02":
                                    trans = new Transaction(TransTypeEnum.deposit,amount);
                                    account.depositAccount(trans);
                                    break;
                                case "C03":
                                    trans = new Transaction(TransTypeEnum.transfer,amount);
                                    account.transferAccount(trans);
                                    break;
                                case "C04":
                                    trans = new Transaction(TransTypeEnum.card,amount);
                                    account.useCard(trans);
                                    break;
                                case "open":
                                    customer.openAccount(AccountTypeEnum.credit, amount);
                                    account.useCard(trans);
                                    break;
                                case "delSingle":
                                    trans = new Transaction(TransTypeEnum.card,amount);
                                    account.useCard(trans);
                                    break;
                                case "delAll":
                                    trans = new Transaction(TransTypeEnum.card,amount);
                                    account.useCard(trans);
                                    break;
                                default:
                                     break;
                            }
                        }
                    }
                }
            }
        }
        
        
        
    }
}
