package com.dysy.demo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class InitManagerLoginSurface extends JFrame {

	private JPanel contentPane;//底层面板，创建管理员登录界面时使用
	private JTextField accountText;//账号输入框
	private JPasswordField codePassword;//密码输入框

	/**
	 * 启动应用
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InitManagerLoginSurface frame = new InitManagerLoginSurface();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * 创建管理员登录界面
	 */
	public InitManagerLoginSurface() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(700, 300, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		setContentPane(contentPane);
		
		JLabel label = new JLabel("\u7BA1\u7406\u5458\u767B\u5F55");//显示管理员登录提示信息
		label.setFont(new Font("宋体", Font.PLAIN, 20));
		
		JLabel accountLabel = new JLabel("\u8D26\u53F7");//账号标签
		accountLabel.setFont(new Font("宋体", Font.PLAIN, 18));
		
		JLabel passwordLabel = new JLabel("\u5BC6\u7801");//密码标签
		passwordLabel.setFont(new Font("宋体", Font.PLAIN, 18));
		
		accountText = new JTextField();
		accountText.setFont(new Font("宋体", Font.PLAIN, 18));
		accountText.setColumns(10);
		accountText.setOpaque(false);
		
		codePassword = new JPasswordField();
		codePassword.setFont(new Font("宋体", Font.PLAIN, 18));
		codePassword.setOpaque(false);
		//限制密码框只能输入数字
		codePassword.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent e) {
				int key = e.getKeyChar();
				if((!(key >= KeyEvent.VK_0 && key <= KeyEvent.VK_9)))
				{
					e.consume();
				}
			}
		});
		
		JButton loginButton = new JButton("\u767B\u5F55");//登录按钮
		loginButton.setBackground(new Color(175, 238, 238));
		loginButton.setBorderPainted(false);
		loginButton.setFocusPainted(false);
		loginButton.addActionListener(new loginButtonHandler(accountText,codePassword));
		
		JButton exitButton = new JButton("\u8FD4\u56DE");//返回按钮
		exitButton.setBackground(new Color(216, 191, 216));
		exitButton.setBorderPainted(false);
		exitButton.setFocusPainted(false);
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				new InitMainFrame().setVisible(true);
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(74)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(passwordLabel)
						.addComponent(accountLabel))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(loginButton)
							.addPreferredGap(ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
							.addComponent(exitButton))
						.addComponent(codePassword)
						.addComponent(accountText, GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE))
					.addContainerGap(103, Short.MAX_VALUE))
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap(162, Short.MAX_VALUE)
					.addComponent(label)
					.addGap(160))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(11)
					.addComponent(label)
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(accountLabel)
						.addComponent(accountText, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(passwordLabel)
						.addComponent(codePassword, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(40)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(loginButton)
						.addComponent(exitButton))
					.addContainerGap(57, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}
	
	/**
	 * @ClassName loginButtonHandler
	 * @Description 创建内部类，给登录按钮添加事件处理
	 */
	public class loginButtonHandler implements ActionListener{
		private JTextField accountText;//文本框
		private JPasswordField codePassword;//密码框
		
		/**
		 * @param accountText
		 * @param codePassword
		 */
		public loginButtonHandler(JTextField accountText,JPasswordField codePassword) {
			this.accountText = accountText;
			this.codePassword = codePassword;
		}
		
		/**
		 * 实现ActionListener接口的actionPerformed()方法 
		 */
		public void actionPerformed(ActionEvent e) {
			if(accountText.getText().equals("@123456") && new String(codePassword.getPassword()).equals("123456"))
			{
				dispose();
				InitManagerSurface managerSurface = new InitManagerSurface();
				managerSurface.setVisible(true);
			}
			else
			{
				JOptionPane.showMessageDialog(null,"账号或密码错误，请重新输入","提示消息",JOptionPane.ERROR_MESSAGE);
			}
		}
	}

}