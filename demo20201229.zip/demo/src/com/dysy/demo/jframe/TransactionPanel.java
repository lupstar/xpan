package com.dysy.demo.jframe;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.dysy.demo.beans.Account;
import com.dysy.demo.beans.Customer;
import com.dysy.demo.beans.TransTypeEnum;
import com.dysy.demo.beans.Transaction;

public class TransactionPanel extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	/**
	 * 启动应用
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TransactionPanel frame = new TransactionPanel(null,new Account("",BigDecimal.ZERO));
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

    
	public TransactionPanel(Long custId,Account account) {
    	
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 500);
    	
    	JPanel contentPane = new JPanel();
		contentPane.setForeground(Color.LIGHT_GRAY);
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new GridLayout(3,1));
		setResizable(false);
		setContentPane(contentPane);
		
		final JPanel accountDetailPanel = new JPanel();
		accountDetailPanel.setForeground(Color.LIGHT_GRAY);
		accountDetailPanel.setBackground(new Color(248, 248, 255));
		accountDetailPanel.setBorder(BorderFactory.createEtchedBorder());
		accountDetailPanel.setLayout(new GridLayout(2,2));
		contentPane.add(accountDetailPanel);
		
		//账户交易操作选择面板
		final JPanel transButtonPanel = new JPanel();
		transButtonPanel.setForeground(Color.LIGHT_GRAY);
		transButtonPanel.setBackground(new Color(248, 248, 255));
		transButtonPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		contentPane.add(transButtonPanel);
		
		//账户交易操作选择面板
		final JPanel transDataPanel = new JPanel();
		transDataPanel.setForeground(Color.LIGHT_GRAY);
		transDataPanel.setBackground(new Color(248, 248, 255));
		transDataPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		transDataPanel.setVisible(false);
		contentPane.add(transDataPanel);
		
		JLabel labelMark=new JLabel(); 
		labelMark.setVisible(false);
		transDataPanel.add(labelMark);
		JTextField txtfield31=new JTextField(20); 
        JLabel label31=new JLabel(); 
        transDataPanel.add(label31);
        transDataPanel.add(txtfield31);
        JTextField txtfield32=new JTextField(20); 
        JLabel label32=new JLabel(); 
        label32.setText("转账账户:");
        label32.setVisible(false);
        txtfield32.setVisible(false);
        transDataPanel.add(label32);
        transDataPanel.add(txtfield32);
        
        JButton tranSubmitButton = new JButton("提交");
        tranSubmitButton.setBorderPainted(false);//设置按钮边框不可见
        tranSubmitButton.setFocusPainted(false);//当点击按钮时不出现边框
        tranSubmitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Account msgAccount = account;
				try {
					if(txtfield31.getText()==null||"".equals(txtfield31.getText())) {
						throw new Exception("金额不能为空");
					}
					TransTypeEnum  transTypeEnum = TransTypeEnum.getTransTypeEnumByCode(labelMark.getText());
					Transaction transaction = new Transaction(transTypeEnum, new BigDecimal(txtfield31.getText()));
					
					switch (transTypeEnum.getTransCode()) {
					case "C01":
						account.withdralAccount(transaction);
						break;
					case "C02":
						account.depositAccount(transaction);
						break;
					case "C03":
						if(txtfield32.getText()==null||"".equals(txtfield32.getText())) {
							throw new Exception("转账账户不能为空");
						}
						if(account.getAccountNumber().equals(txtfield32.getText())) {
							throw new Exception("转账账户不能是本账户");
						}
						Customer transferCustomer = account.queryCustomerByAccountNumber(txtfield32.getText());
						if(transferCustomer==null) {
							throw new Exception("转账账户["+txtfield32.getText()+"]不存在！");
						}
						for(Account transAccount:transferCustomer.getAccountList()) {
							if(transAccount.getAccountNumber().equals(txtfield32.getText())) {
								msgAccount = transAccount;
								Transaction transferTrans = new Transaction(TransTypeEnum.transfer, BigDecimal.ZERO.subtract(transaction.getAmount()));
								transAccount.transferAccount(transferTrans);
							}
						}
						msgAccount = account;
						account.transferAccount(transaction);
						break;
					case "C04":
						account.useCard(transaction);
						break;
					default:
						throw new Exception("无此交易！");
					}
					
					JOptionPane.showMessageDialog(null, "交易成功", "提示消息", JOptionPane.ERROR_MESSAGE);
					dispose();
					new CustomerPanel(new JPanel(),custId,account.getAccountNumber()).setVisible(true);
				}catch(Exception ex) {
					String exceptAccount = msgAccount.getAccountNumber();
					String type = msgAccount.getAccountType();
					String prexMsg = type+" xxx-"+exceptAccount.substring(exceptAccount.length()-4)+" ";
					JOptionPane.showMessageDialog(null, prexMsg+ex.getMessage(), "提示消息", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
        transDataPanel.add(tranSubmitButton);
		
		List<TransTypeEnum> functionList = account.getTransFunction();
		for(TransTypeEnum func:functionList) {
			JButton withdrawalButton = new JButton(func.getName());//交易按钮
			withdrawalButton.setBorderPainted(false);//设置按钮边框不可见
			withdrawalButton.setFocusPainted(false);//当点击按钮时不出现边框
			//给管理员按钮添加事件处理
			withdrawalButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.out.println(e.getActionCommand());
					TransTypeEnum transTypeEnum = TransTypeEnum.getTransTypeEnumByName(e.getActionCommand());
					if(transTypeEnum!=null) {
				        label31.setText(transTypeEnum.getName()+"金额：");
					}
					transDataPanel.setVisible(true);
					label32.setVisible(transTypeEnum.transfer.getName().equals(e.getActionCommand()));
					txtfield32.setVisible(transTypeEnum.transfer.getName().equals(e.getActionCommand()));
					labelMark.setText(transTypeEnum.getTransCode());

				}
			});
	        transButtonPanel.add(withdrawalButton);
		}
		JButton exitButton = new JButton("返回");
		exitButton.setBorderPainted(false);//设置按钮边框不可见
		exitButton.setFocusPainted(false);//当点击按钮时不出现边框
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				new CustomerPanel(new JPanel(),custId,account.getAccountNumber()).setVisible(true);
			}
		});
		transButtonPanel.add(exitButton);
		
		JTextField txtfield1=new JTextField(20); 
        txtfield1.setEditable(false);
        JLabel label1=new JLabel("帐户号："); 
        txtfield1.setText(account.getAccountNumber());
        accountDetailPanel.add(label1);
        accountDetailPanel.add(txtfield1);
        
        JTextField txtfield2=new JTextField(10); 
        txtfield2.setEditable(false);
        JLabel label2=new JLabel("帐户余额："); 
        txtfield2.setText(account.getBalance().toString());
        accountDetailPanel.add(label2);
        accountDetailPanel.add(txtfield2);
		//账户交易操作面板
        
		
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
				gl_contentPane.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_contentPane.createSequentialGroup()
						.addGap(163)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false))
						.addContainerGap(166, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
				gl_contentPane.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_contentPane.createSequentialGroup()
						.addGap(54)
						.addContainerGap(35, Short.MAX_VALUE))
			);
    	
    }


}
