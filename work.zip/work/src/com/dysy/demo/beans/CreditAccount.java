package com.dysy.demo.beans;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CreditAccount extends Account {

	//信用卡属性
    private Long card;

    public Long getCard() {
        return card;
    }

    public void setCard(Long card) {
        this.card = card;
    }
    
    public String getAccountType() {
    	return AccountTypeEnum.credit.getAccountType();
    }
    
    
    public List<TransTypeEnum> getTransFunction() {
    	List<TransTypeEnum> transTypeEnumList = new ArrayList<>();
    	return Arrays.asList(TransTypeEnum.values());
    }

}
