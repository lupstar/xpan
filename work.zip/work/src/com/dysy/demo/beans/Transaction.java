package com.dysy.demo.beans;

import java.math.BigDecimal;
import java.util.UUID;


public class Transaction {

    private UUID transId;
    private TransTypeEnum transType;
    //签名的数字值,可正可负
    private BigDecimal amount;

    public UUID getTransId() {
        return transId;
    }

    public void setTransId(UUID transId) {
        this.transId = transId;
    }

    public TransTypeEnum getTransType() {
        return transType;
    }

    public void setTransType(TransTypeEnum transType) {
        this.transType = transType;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

}
