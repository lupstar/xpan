package com.dysy.demo.beans;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.dysy.demo.dataload.FileReaderAndWrite;

public abstract class Account implements TransactionOperation {

	private String accountNumber;

	private BigDecimal balance;
	
	public Account(String accountNumber,BigDecimal balance) {
		this.accountNumber = accountNumber;
		this.balance = balance;
	}

	/**
	 * 账户类型
	 * @return
	 */
	public abstract AccountTypeEnum getAccountType();
	
	public String getAccountNumber() {
		return accountNumber;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	
	public void withdralAccount(Transaction trans) throws Exception {
		this.checkTransAmount(trans);
		
		List<TransTypeEnum> transTypeEnumList = this.getTransFunction();
		if(transTypeEnumList.contains(TransTypeEnum.withdrawal)) {
			Customer customer = this.queryCustomerByAccountNumber(accountNumber);
			FileReaderAndWrite.writeAccount(this, customer.getCustId(), trans,null);
			FileReaderAndWrite.writeTransRecord(this, customer.getCustId(), trans);
		}else {
			throw new Exception("不允许此交易");
		}
	};

	public void depositAccount(Transaction trans) throws Exception {
		this.checkTransAmount(trans);
		
		List<TransTypeEnum> transTypeEnumList = this.getTransFunction();
		if(transTypeEnumList.contains(TransTypeEnum.deposit)) {
			Customer customer = this.queryCustomerByAccountNumber(accountNumber);
			FileReaderAndWrite.writeAccount(this, customer.getCustId(), trans,null);
			FileReaderAndWrite.writeTransRecord(this, customer.getCustId(), trans);
		}else {
			throw new Exception("不允许此交易");
		}
	};

	public void transferAccount(Transaction trans,String transferAccountNo) throws Exception {
		this.checkTransAmount(trans);
		
		Customer transferCustomer = this.queryCustomerByAccountNumber(transferAccountNo);
		if(transferCustomer==null) {
			throw new Exception("转账账户["+transferCustomer+"]不存在！");
		}
		//转入账户操作
		for(Account transAccount:transferCustomer.getAccountList()) {
			if(transAccount.getAccountNumber().equals(transferAccountNo)) {
				Transaction transferTrans = new Transaction(trans.getTransId(),TransTypeEnum.transfer, BigDecimal.ZERO.subtract(trans.getAmount()));
				transAccount.tranSingleAccountOper(transferTrans);
			}
		}
		//本人账户转账操作
		this.tranSingleAccountOper(trans);
	};

	public void useCard(Transaction trans) throws Exception {
		this.checkTransAmount(trans);
		
		List<TransTypeEnum> transTypeEnumList = this.getTransFunction();
		if(transTypeEnumList.contains(TransTypeEnum.card)) {
			Customer customer = this.queryCustomerByAccountNumber(accountNumber);
			FileReaderAndWrite.writeAccount(this, customer.getCustId(), trans,null);
			FileReaderAndWrite.writeTransRecord(this, customer.getCustId(), trans);
		}else {
			throw new Exception("不允许此交易");
		}
	};
	
	/**
	 * 账户所拥有的所有功能事务
	 * @return
	 */
	public List<TransTypeEnum> getTransFunction() {
		return Arrays.asList(TransTypeEnum.values());
	}

	/**
	 * 基本金额校验
	 * @param trans
	 * @throws Exception
	 */
	public void checkTransAmount(Transaction trans) throws Exception {
		// 取款金额必须为负
		if (TransTypeEnum.withdrawal.getTransCode().equals(trans.getTransType().getTransCode())) {
			if (trans.getAmount().compareTo(BigDecimal.ZERO) > 0) {
				throw new Exception("取款金额不能为正数");
			}
			// 当客户将钱存入账户时，存款的金额必须为正
		} else if (TransTypeEnum.deposit.getTransCode().equals(trans.getTransType().getTransCode())) {
			if (trans.getAmount().compareTo(BigDecimal.ZERO) < 0) {
				throw new Exception("存款金额不能为负数");
			}
			// 账或刷卡交易金额可为正数或负数
		} else {
			return;
		}
	};
	
	/**
	 * 根据账户号查询所属用户
	 * @param accountNumber
	 * @return
	 * @throws Exception
	 */
	public Customer queryCustomerByAccountNumber(String accountNumber) throws Exception {
		// 取款金额必须为负
		List<Customer> customers = new ArrayList<Customer>();
		FileReaderAndWrite.loadData(customers);
		for(Customer customer:customers) {
			for(Account account:customer.getAccountList()) {
				if(account.getAccountNumber().equals(accountNumber)) {
					return customer;
				}
			}
		}
		return null;
	};
	
	/**
	 * 转账双方中一方账户操作
	 * @param trans
	 * @throws Exception
	 */
	private void tranSingleAccountOper(Transaction trans) throws Exception {
		this.checkTransAmount(trans);
		
		List<TransTypeEnum> transTypeEnumList = this.getTransFunction();
		if(transTypeEnumList.contains(TransTypeEnum.transfer)) {
			Customer customer = this.queryCustomerByAccountNumber(accountNumber);
			FileReaderAndWrite.writeAccount(this, customer.getCustId(), trans,null);
			FileReaderAndWrite.writeTransRecord(this, customer.getCustId(), trans);
		}else {
			throw new Exception("不允许此交易");
		}
	}

}
