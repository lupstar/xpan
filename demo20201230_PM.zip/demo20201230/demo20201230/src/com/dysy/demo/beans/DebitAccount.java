package com.dysy.demo.beans;

import java.math.BigDecimal;

public class DebitAccount extends Account {

	//信用卡属性
    private Long card;

    public DebitAccount(String accountNumber, BigDecimal balance,Long card) {
		super(accountNumber, balance);
		this.card = card;
	}
    
    public Long getCard() {
        return card;
    }
    
    /**
     * 账户类型
     */
    @Override
    public AccountTypeEnum getAccountType() {
    	return AccountTypeEnum.debit;
    }
    
    
    /**
     * 借方账户不能有负余额，所以任何负金额的交易都需要检查它不会导致余额变为负。如果是这样，则必须拒绝该事务。
     * @throws Exception 
     */
    @Override
    public void checkTransAmount(Transaction trans) throws Exception {
    	if(this.getBalance().add(trans.getAmount()).compareTo(BigDecimal.ZERO)<0) {
    		throw new Exception("金额不足");
    	}
    	super.checkTransAmount(trans);
    }

}
