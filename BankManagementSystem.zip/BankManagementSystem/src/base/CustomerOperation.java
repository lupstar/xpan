package base;

import java.math.BigDecimal;

import Systemdesign.Account;
import systemdesignenum.AccountTypeEnum;
//This is an interface used as functions of the customer class.The functions are to open account, delete an account,and delete all accounts;
public interface CustomerOperation {

    /**
     * 用户单个账户开户
     *
     * @param accountTypeEnum
     * @param openAmount
     * @throws Exception
     */
    public void openAccount(AccountTypeEnum accountTypeEnum, BigDecimal openAmount) throws Exception;

    /**
     * 注销单个账户
     *
     * @param account
     * @throws Exception
     */
    public void deleteAccount(Account account) throws Exception;

    /**
     * 注销某用户下的所有账户
     *
     * @throws Exception
     */
    public void deleteAllAccount() throws Exception;
}
