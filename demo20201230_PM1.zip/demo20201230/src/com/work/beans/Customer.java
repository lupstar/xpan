package com.work.beans;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.work.beans.base.CustomerOperation;
import com.work.beans.enums.AccountTypeEnum;
import com.work.beans.enums.TransTypeEnum;
import com.work.fileOperation.FileReaderAndWrite;

public class Customer implements CustomerOperation{

    private String custName;

    private Long custId;

    private LocalDate birthDate;

    private List<Account> accountList;
    
    public Customer(Long custId) {
    	this.custId = custId;
    }
    
    public Customer(String custName,Long custId,LocalDate birthDate,List<Account> accountList) {
    	this.custName = custName;
    	this.custId = custId;
    	this.birthDate = birthDate;
    	this.accountList = accountList;
    }

    public Customer() {
		// TODO Auto-generated constructor stub
	}

	public String getCustName() {
        return custName;
    }

    public Long getCustId() {
        return custId;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }


    public List<Account> getAccountList() {
        return accountList;
    }
    
    /**
     * 校验：一个客户最多只能拥有5个银行账户
     * @param accountList
     * @throws Exception
     */
    private void checkAccountNumber() throws Exception{
    	if(accountList.size()==5) {
    		throw new Exception("最多建立5个账户...");
    	}
    }
    
    /**
     * 校验：已经有至少一个信用账户的情况下，只能开立一个储蓄账户
     * @param account
     * @throws Exception
     */
    private void checkOpenAccountType(AccountTypeEnum accountTypeEnum) throws Exception {
    	int savingAccountCount = 0;
    	boolean existCreditAccount = false;
    	for(Account existAccount:accountList) {
    		if(AccountTypeEnum.credit.equals(existAccount.getAccountType())) {
    			existCreditAccount = true;
    		}else if(AccountTypeEnum.savings.equals(existAccount.getAccountType())) {
    			savingAccountCount++;
    		}
    	}
    	if(accountTypeEnum.getAccountType().equals(AccountTypeEnum.savings.getAccountType())
    			&&existCreditAccount&&savingAccountCount>0) {
    		throw new Exception("已有至少一个信用账户，只能开立一个储蓄账户");
    	}
    }
    
    /**
     * 校验：未成年人只能开立借方账户，未成年人是指开户时不满18(18)岁的客户
     * @param account
     * @throws Exception
     */
    private void checkAgePrinciple(AccountTypeEnum accountTypeEnum) throws Exception {
    	boolean isJuveniles = LocalDate.now().compareTo(this.birthDate)<=18;
    	if(isJuveniles&&!AccountTypeEnum.credit.getAccountType()
				.equals(accountTypeEnum.getAccountType())) {
			throw new Exception("不满18(18)岁的客户只能开立借方账户");
		}
    }
    
    public void openAccount(AccountTypeEnum accountTypeEnum,BigDecimal openAmount) throws Exception {
    	Account account = null;
    	Transaction transaction = null;
    	this.checkAccountNumber();
    	this.checkOpenAccountType(accountTypeEnum);
    	this.checkAgePrinciple(accountTypeEnum);
    	
    	switch(accountTypeEnum.getAccountType()){
    		case "Credit":
    			account = new CreditAccount(KeyGenerator.getIbanKey(), BigDecimal.ZERO, KeyGenerator.getCardIdKey());
    			break;
    		case "Debit":
    			account = new DebitAccount(KeyGenerator.getIbanKey(), BigDecimal.ZERO, KeyGenerator.getCardIdKey());
    			break;
    		case "Savings":
    			account = new SavingsAccount(KeyGenerator.getIbanKey(), BigDecimal.ZERO,null);
    			break;
    	}

    	if(openAmount!=null) {
    		if(openAmount.compareTo(BigDecimal.ZERO)>0) {
    			transaction = new Transaction(TransTypeEnum.deposit, openAmount);
    		}else if(openAmount.compareTo(BigDecimal.ZERO)<0) {
    			throw new Exception("开户存款金额不能小于0");
    		}
    	}
    	//开户
    	FileReaderAndWrite.writeAccount(account, custId, null, "add");
    	//预存款
    	if(transaction!=null) {
    		account.depositAccount(transaction);
    	}
    }
    
    public void deleteAccount(Account account) throws Exception {
    	if(account.getBalance().compareTo(BigDecimal.ZERO)!=0) {
    		throw new Exception("账户余额不为0，不能销户");
    	}else {
    		//删除账户
    		FileReaderAndWrite.writeAccount(account, custId, null, "del");
    	}
    	
    }
    
    public void deleteAllAccount() throws Exception {
		Customer customer = this.queryCustomerByCustId(this.custId);
    	List<Account> accounts = customer.getAccountList();
    	for(Account account:accounts) {
    		if(account.getBalance().compareTo(BigDecimal.ZERO)!=0) {
    			throw new Exception("账户["+account.getAccountNumber()+"]余额未结清，不能注销");
    		}
    	}
    	//删除全部账户
    	for(Account account:accounts) {
    		FileReaderAndWrite.writeAccount(account, custId, null, "del");
    	}
    }
    
    public Customer queryCustomerByCustId(Long custId) throws Exception {
    	// 取款金额必须为负
    	List<Customer> customers = new ArrayList<Customer>();
    	FileReaderAndWrite.loadData(customers);
    	for(Customer customer:customers) {
    		if(custId.compareTo(customer.getCustId())==0) {
    			return customer;
    		}
    	}
    	throw new Exception("用户ID【"+custId+"】系统中不存在");
    }

    
}
