package com.dysy.demo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Color;
import java.awt.Font;

public class InitMainFrame extends JFrame {
	private JPanel contentPane;//底层面板
	public static List<UserInfo> info;//储存序列化时用户信息的类变量，用于本类初始化文件时，存储写入文件的对象
	public static List<UserInfo> list = new ArrayList<UserInfo>();//储存反序列化时读取的用户的信息，当文件被修改时，调用此变量存储用户信息
	public static UserFile userFile;//用户文件对象，用于储存和读取文件时调用相关方法

	/**
	 * 启动应用
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InitMainFrame frame = new InitMainFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * 创建主登录面板
	 */
	public InitMainFrame() {
		userFile = new UserFile();
		String filePath = System.getProperty("user.dir");//获取当前项目的路径
		filePath+="\\src\\com\\dysy\\demo\\UserInfo.txt";//得到当前包的路径
		if(new File(filePath).exists() == false)//若用户信息的文件不存在，则初始化
		{
			info = new ArrayList<UserInfo>();
			info.add(new UserInfo("123456","1234560",10000));
			userFile.saveFile(info);
		}
		else
		{
			InitMainFrame.list = (List<UserInfo>) InitMainFrame.userFile.printFile();//若文件存在，则将文件反序列化读取 
		}
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(700, 300, 481, 347);
		contentPane = new JPanel();
		contentPane.setForeground(Color.LIGHT_GRAY);
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		setContentPane(contentPane);
		
		JButton managerButton = new JButton("\u7BA1\u7406\u5458");//管理员按钮
		managerButton.setBackground(new Color(255, 204, 204));
		managerButton.setForeground(Color.BLACK);
		managerButton.setFont(new Font("宋体", Font.PLAIN, 18));
		managerButton.setBorderPainted(false);//设置按钮边框不可见
		managerButton.setFocusPainted(false);//当点击按钮时不出现边框
		//给管理员按钮添加事件处理
		managerButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				InitManagerLoginSurface mLogin = new InitManagerLoginSurface();
				mLogin.setVisible(true);
				
			}
		});
		
		JButton userButton = new JButton("\u7528  \u6237");//用户按钮
		userButton.setBackground(new Color(204, 204, 255));
		userButton.setFont(new Font("宋体", Font.PLAIN, 18));
		userButton.setBorderPainted(false);//设置按钮边框不可见
		userButton.setFocusPainted(false);//当点击按钮时不出现边框
		//给用户按钮添加事件处理
		userButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InitUserLoginSurface uLogin = new InitUserLoginSurface();
				dispose();
				uLogin.setVisible(true);
			}
		});
		
		JButton exitButton = new JButton("\u9000\u51FA");//退出按钮
		exitButton.setBackground(new Color(255, 218, 185));
		exitButton.setBorderPainted(false);//设置按钮边框不可见
		exitButton.setFocusPainted(false);//当点击按钮时不出现边框
		//当点击退出时，程序运行结束
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap(377, Short.MAX_VALUE)
					.addComponent(exitButton)
					.addGap(25))
				.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
					.addGap(176)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(userButton, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 103, Short.MAX_VALUE)
						.addComponent(managerButton, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 103, Short.MAX_VALUE))
					.addGap(186))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(78)
					.addComponent(managerButton)
					.addGap(30)
					.addComponent(userButton)
					.addPreferredGap(ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
					.addComponent(exitButton)
					.addGap(46))
		);
		contentPane.setLayout(gl_contentPane);
	}

}
