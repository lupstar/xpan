package com.work.beans.enums;


public enum AccountTypeEnum {

    credit("Credit","借方"),

    debit("Debit","贷方"),

    savings("Savings","储蓄");


    private String accountType;

    private String description;

    public String getAccountType() {
        return accountType;
    }

    public String getDescription() {
        return description;
    }

    AccountTypeEnum(String accountType, String description){
        this.accountType = accountType;
        this.description = description;
    }
}
