package com.work.panel;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.work.beans.Account;
import com.work.beans.CreditAccount;
import com.work.beans.Customer;
import com.work.beans.DebitAccount;
import com.work.beans.SavingsAccount;
import com.work.beans.enums.AccountTypeEnum;
import com.work.fileOperation.FileReaderAndWrite;

public class CustomerPanel extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;
	
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    CustomerPanel frame = new CustomerPanel(null,null);
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public CustomerPanel(Long queryCustId,String queryAccountNo) {
    	//加载文件数据
    	List<Customer> customers = new ArrayList<>();
    	try {
    		FileReaderAndWrite.loadData(customers);
    	}catch (Exception e) {
			e.printStackTrace();
		}
    	
    	//总面板初始化
    	contentPane= new JPanel();
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 400);
    	contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
		contentPane.setForeground(Color.LIGHT_GRAY);
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		setContentPane(contentPane);
		//客户及账户查询面板初始化
		final JPanel queryPanel = new JPanel();
		queryPanel.setBackground(new Color(248, 248, 255));
		getContentPane().add(queryPanel);
		contentPane.add(queryPanel);
		
		JLabel label=new JLabel("客户ID：");    
        JComboBox cmb=new JComboBox(); 
        cmb.addItem("--请选择--");
        JLabel accountLabel=new JLabel("账户：");    
        JComboBox accountCmb=new JComboBox();
        accountCmb.addItem("--请选择--");
        
        //查询面板加载组件
        queryPanel.add(label);
        if(queryCustId!=null) {
        	for(int i=0;i<cmb.getItemCount();i++){
        		String item = (String) cmb.getItemAt(i);
        		if(item.indexOf(queryCustId.toString())>0) {
        			cmb.setSelectedIndex(i);
        			break;
        		}
        	}
        }
        queryPanel.add(cmb);
        
        queryPanel.add(accountLabel);
        if(queryAccountNo!=null) {
        	for(int i=1;i<accountCmb.getItemCount();i++){
        		String item = (String) accountCmb.getItemAt(i);
        		String endNo = item.split("-")[1];
        		if(queryAccountNo.endsWith(endNo)) {
        			accountCmb.setSelectedIndex(i);
        			break;
        		}
        	}
        }
        queryPanel.add(accountCmb);
        
		//客户信息面板初始化
		final JPanel customerPanel = new JPanel();
		customerPanel.setBackground(new Color(248, 248, 255));
		getContentPane().add(customerPanel);
		customerPanel.setVisible(false);
		contentPane.add(customerPanel);
		
		JTextField txtfield1=new JTextField(10); 
		txtfield1.setEditable(false);
        JLabel label1=new JLabel("姓名："); 
        customerPanel.add(label1);
        customerPanel.add(txtfield1);
        JLabel label2=new JLabel("客户ID："); 
        JTextField txtfield2=new JTextField(10); 
        txtfield2.setEditable(false);
        customerPanel.add(label2);
        customerPanel.add(txtfield2);
        JTextField txtfield3=new JTextField(10); 
        txtfield3.setEditable(false);
        JLabel label3=new JLabel("出生日期："); 
        customerPanel.add(label3);
        customerPanel.add(txtfield3);
        JTextField txtfield4=new JTextField(10); 
        txtfield4.setEditable(false);
        JLabel label4=new JLabel("帐户数量："); 
        customerPanel.add(label4);
        customerPanel.add(txtfield4);
        
		//账户信息面板
		final JPanel accountPanel = new JPanel();
		accountPanel.setBackground(new Color(248, 248, 255));
		getContentPane().add(accountPanel);
		accountPanel.setVisible(false);
		contentPane.add(accountPanel);
		
        JLabel label5=new JLabel("账户编号："); 
        final JTextField txtfield5=new JTextField(20); 
		txtfield5.setEditable(false);
        accountPanel.add(label5);
        accountPanel.add(txtfield5);
        JLabel label6=new JLabel("账户余额："); 
        JTextField txtfield6=new JTextField(10); 
        txtfield6.setEditable(false);
        accountPanel.add(label6);
        accountPanel.add(txtfield6);
        JLabel label7=new JLabel("卡参数："); 
        JTextField txtfield7=new JTextField(20); 
        txtfield7.setEditable(false);
        label7.setVisible(false);
        txtfield7.setVisible(false);
        accountPanel.add(label7);
        accountPanel.add(txtfield7);
        JLabel label8=new JLabel("利率："); 
        JTextField txtfield8=new JTextField(10); 
        txtfield8.setEditable(false);
        label7.setVisible(false);
        txtfield8.setVisible(false);
        accountPanel.add(label8);
        accountPanel.add(txtfield8);
        
        //客户Id下拉框数据加载
        for(Customer customer:customers) {
        	Long custId = customer.getCustId();
        	String custName = customer.getCustName();
        	cmb.addItem(custName+"("+custId+")");
        }
        //客户Id下拉框选中事件触发
        cmb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String custInfo =(String) cmb.getSelectedItem();
				//为选中提示选择用户
				if(custInfo==null||"--请选择--".equals(custInfo)) {
					customerPanel.setVisible(false);
					accountPanel.setVisible(false);
					accountCmb.removeAllItems();
					accountCmb.addItem("--请选择--");
					JOptionPane.showMessageDialog(null, "请选择客户", "提示消息", JOptionPane.ERROR_MESSAGE);
					return;
				}
				//选中展示客户面板并加载账户下拉框选项
				Long custId = Long.valueOf(custInfo.substring(custInfo.indexOf("(")+1,custInfo.indexOf(")")));
				for(Customer customer:customers) {
					if(customer.getCustId().compareTo(custId)==0) {
						txtfield1.setText(customer.getCustName());
						txtfield2.setText(customer.getCustId().toString());
						txtfield3.setText(customer.getBirthDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
						txtfield4.setText(new Integer(customer.getAccountList().size()).toString());
						customerPanel.setVisible(true);
						
						accountCmb.removeAllItems();
						accountCmb.addItem("--请选择--");
						for(Account account:customer.getAccountList()) {
							String accountNumber = account.getAccountNumber();
							String type = account.getAccountType().getAccountType();
							accountCmb.addItem(type+" xxx-"+accountNumber.substring(accountNumber.length()-4));
						}
						accountPanel.setVisible(false);
						
					}
				}
			}
		});
        
        //账户下拉框触发事件：账户面板显示
        accountCmb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String custInfo =(String) cmb.getSelectedItem();
				String accountNumber =(String) accountCmb.getSelectedItem();
				if(accountNumber==null||"--请选择--".equals(accountNumber)) {
					return;
				}
				Long custId = Long.valueOf(custInfo.substring(custInfo.indexOf("(")+1,custInfo.indexOf(")")));
				String endAccount = accountNumber.split("-")[1];
				for(Customer customer:customers) {
					if(customer.getCustId().compareTo(custId)==0) {
						List<Account> accounts = customer.getAccountList();
						for(Account account:accounts) {
							if(account.getAccountNumber().endsWith(endAccount)) {
								txtfield5.setText(account.getAccountNumber());
								txtfield6.setText(account.getBalance().toString());
								if(AccountTypeEnum.credit.equals(account.getAccountType())){
                                    txtfield7.setText(((CreditAccount)account).getCard().toString());
                                    txtfield8.setText("");
                                    label7.setVisible(true);
                                    txtfield7.setVisible(true);
                                    label8.setVisible(false);
                                    txtfield8.setVisible(false);
                                }else if(AccountTypeEnum.debit.equals(account.getAccountType())){
                                     txtfield7.setText(((DebitAccount)account).getCard().toString());
                                     txtfield8.setText("");
                                     label7.setVisible(true);
                                     txtfield7.setVisible(true);
                                     label8.setVisible(false);
                                     txtfield8.setVisible(false);
                                }else if(AccountTypeEnum.savings.equals(account.getAccountType())){
                                    txtfield7.setText("");
                                    BigDecimal rate = ((SavingsAccount)account).getInterestRate();
                                     txtfield8.setText(rate==null?"":rate.toString());
                                     label7.setVisible(false);
                                     txtfield7.setVisible(false);
                                     label8.setVisible(true);
                                     txtfield8.setVisible(true);
                                }
								accountPanel.setVisible(true);
                                                                
							}
						}
					}
				}
			}
		});

        //组装面板组件
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
				gl_contentPane.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_contentPane.createSequentialGroup()
						.addGap(163)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false))
						.addContainerGap(166, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
				gl_contentPane.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_contentPane.createSequentialGroup()
						.addGap(54)
						.addContainerGap(35, Short.MAX_VALUE))
		);
    	
    }

}
