package com.work.beans.base;

import com.work.beans.Transaction;

/**
 * 事务操作接口
 * @author
 *
 */
public interface TransactionOperation {
	
	/**
	 * 提款
	 * @param trans
	 * @throws Exception
	 */
    public void withdralAccount(Transaction trans) throws Exception;

    /**
     * 存款
     * @param trans
     * @throws Exception
     */
    public void depositAccount(Transaction trans) throws Exception;

    /**
     * 转账
     * @param trans
     * @param transferAccountNo
     * @throws Exception
     */
    public void transferAccount(Transaction trans,String transferAccountNo) throws Exception;

    /**
     * 刷卡
     * @param trans
     * @throws Exception
     */
    public void useCard(Transaction trans) throws Exception;

}
