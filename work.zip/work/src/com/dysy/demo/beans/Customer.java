package com.dysy.demo.beans;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Customer implements CustomerOperation{

    private String custName;

    private Long custId;

    private LocalDate birthDate;

    private List<Account> accountList = new ArrayList<>();

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public Long getCustId() {
        return custId;
    }

    public void setCustId(Long custId) {
        this.custId = custId;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public List<Account> getAccountList() {
        return accountList;
    }

    public void setAccountList(List<Account> accountList) throws Exception {
        this.accountList = accountList;
    }
    
    /**
     * 一个客户最多只能拥有5个银行账户
     * @param accountList
     * @throws Exception
     */
    private void checkAccountNumber() throws Exception{
    	if(accountList.size()==5) {
    		throw new Exception("account number limit five...");
    	}
    }
    
    /**
     * 已经有至少一个信用账户的情况下，只能开立一个储蓄账户
     * @param account
     * @throws Exception
     */
    private void checkOpenAccountType(Account account) throws Exception {
    	int savingAccountCount = 0;
    	boolean existCreditAccount = false;
    	for(Account existAccount:accountList) {
    		if(AccountTypeEnum.credit.getAccountType()
    				.equals(existAccount.getAccountType().toString())) {
    			existCreditAccount = true;
    		}else if(AccountTypeEnum.savings.getAccountType()
    				.equals(existAccount.getAccountType().toString())) {
    			savingAccountCount++;
    		}
    	}
    	if(existCreditAccount&&savingAccountCount>0) {
    		throw new Exception("此账户不符合开通原则");
    	}
    }
    
    /**
     * 未成年人只能开立借方账户，未成年人是指开户时不满18(18)岁的客户
     * @param account
     * @throws Exception
     */
    private void checkAgePrinciple(Account account) throws Exception {
    	boolean isJuveniles = this.birthDate.compareTo(LocalDate.now())<365*18;
    	if(isJuveniles&&!AccountTypeEnum.credit.getAccountType()
				.equals(account.getAccountType().toString())) {
			throw new Exception("此账户不符合开通原则");
		}
    }
    
    public void openAccount(Account account,Transaction transaction) throws Exception {
    	checkAccountNumber();
    	this.checkAgePrinciple(account);
    	this.checkOpenAccountType(account);
    	//开户
    	BigDecimal openAmount = BigDecimal.ZERO;
    	if(transaction!=null) {
    		if(TransTypeEnum.deposit.getTransCode().equals(transaction.getTransType().toString())) {
    			openAmount = transaction.getAmount();
    		}else {
    			throw new Exception("账户未开通，不允许非存款操作");
    		}
    	}
    	//.....
    	
    }
    
    public void deleteAccount(Account account) throws Exception {
    	if(account.getBalance().compareTo(BigDecimal.ZERO)!=0) {
    		throw new Exception("账户余额不为0，不能删除");
    	}else {
    		//删除账户
    	}
    	
    }
    
    public void deleteAllAccount(Customer customer) throws Exception {
    	List<Account> accounts = customer.getAccountList();
    	for(Account account:accounts) {
    		if(account.getBalance().compareTo(BigDecimal.ZERO)!=0) {
    			throw new Exception("存在账户余额未结清，不能删除");
    		}
    	}
    	//删除全部账户
    	
    }
}
