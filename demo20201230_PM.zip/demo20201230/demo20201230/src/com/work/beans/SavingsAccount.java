package com.work.beans;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.dysy.demo.dataload.FileReaderAndWrite;


public class SavingsAccount extends Account {

	//储蓄帐户有一个利率属性
    private BigDecimal interestRate;

    public SavingsAccount(String accountNumber, BigDecimal balance, BigDecimal interestRate) {
		super(accountNumber, balance);
		this.interestRate = interestRate;
	}

	public BigDecimal getInterestRate() {
        return interestRate;
    }
    
    public AccountTypeEnum getAccountType() {
    	return AccountTypeEnum.savings;
    }
    
    /**
     * 储蓄账户不支持银行卡交易或取款。它们允许有存款和转账
     */
    @Override
    public List<TransTypeEnum> getTransFunction() {
    	List<TransTypeEnum> transTypeEnumList = new ArrayList<>();
    	transTypeEnumList.add(TransTypeEnum.deposit);
    	transTypeEnumList.add(TransTypeEnum.transfer);
    	return transTypeEnumList;
    }
    
    /**
     * 储蓄账户允许有正数的存款和转账
     * @throws Exception 
     */
    @Override
    public void checkTransAmount(Transaction trans) throws Exception {
    	if(trans.getAmount().compareTo(BigDecimal.ZERO)<0) {
    		throw new Exception("储蓄账户允许有正数的存款或转账");
    	}
    }
    
    public void withdralAccount(Transaction trans) throws Exception {
    	throw new Exception("不允许此交易");
	};
	
	public void useCard(Transaction trans) throws Exception {
		throw new Exception("不允许此交易");
	};

}
