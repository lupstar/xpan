package com.dysy.demo.jframe;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.dysy.demo.beans.Account;
import com.dysy.demo.beans.Customer;
import com.dysy.demo.dataload.FileReaderAndWrite;

public class CustomerPanel extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                	JPanel contentPane = new JPanel();
                    CustomerPanel frame = new CustomerPanel(contentPane,null,null);
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public CustomerPanel(JPanel contentPane,Long queryCustId,String queryAccountNo) {
    	List<Customer> customers = new ArrayList<>();
    	try {
    		FileReaderAndWrite.loadData(customers);
    	}catch (Exception e) {
			
		}
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 400);
    	contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
		contentPane.setForeground(Color.LIGHT_GRAY);
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		setContentPane(contentPane);
		
		//客户查询面板
		final JPanel queryPanel = new JPanel();
		queryPanel.setBounds(100, 100, 800, 100);
		queryPanel.setForeground(Color.LIGHT_GRAY);
		queryPanel.setBackground(new Color(248, 248, 255));
		queryPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		getContentPane().add(queryPanel);
		contentPane.add(queryPanel);
		//客户信息面板
		final JPanel customerInfoPanel = new JPanel();
		customerInfoPanel.setBounds(100, 100, 800, 200);
		customerInfoPanel.setForeground(Color.LIGHT_GRAY);
		customerInfoPanel.setBackground(new Color(248, 248, 255));
		customerInfoPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		getContentPane().add(customerInfoPanel);
		customerInfoPanel.setVisible(false);
		contentPane.add(customerInfoPanel);
		//账户信息面板
		final JPanel accountPanel = new JPanel();
		accountPanel.setBounds(100, 100, 800, 200);
		accountPanel.setForeground(Color.LIGHT_GRAY);
		accountPanel.setBackground(new Color(248, 248, 255));
		accountPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		getContentPane().add(accountPanel);
		accountPanel.setVisible(false);
		contentPane.add(accountPanel);
		
		final JTextField txtfield1=new JTextField(10); 
		txtfield1.setEditable(false);
        JLabel label1=new JLabel("姓名："); 
        customerInfoPanel.add(label1);
        customerInfoPanel.add(txtfield1);
        JLabel label2=new JLabel("客户ID："); 
        JTextField txtfield2=new JTextField(10); 
        txtfield2.setEditable(false);
        customerInfoPanel.add(label2);
        customerInfoPanel.add(txtfield2);
        JTextField txtfield3=new JTextField(10); 
        txtfield3.setEditable(false);
        JLabel label3=new JLabel("出生日期："); 
        customerInfoPanel.add(label3);
        customerInfoPanel.add(txtfield3);
        JTextField txtfield4=new JTextField(10); 
        txtfield4.setEditable(false);
        JLabel label4=new JLabel("帐户数量："); 
        customerInfoPanel.add(label4);
        customerInfoPanel.add(txtfield4);
        
        JButton openButton = new JButton("开户");
        openButton.setBorderPainted(false);
        openButton.setFocusPainted(false);
        openButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(Customer customer:customers) {
					if(customer.getCustId().toString().equals(txtfield2.getText())) {
						dispose();
						new OpenAccountPanel(customer).setVisible(true);
					}
				}
			}
		});
        customerInfoPanel.add(openButton);
        
        
        JLabel label5=new JLabel("账户编号："); 
        final JTextField txtfield5=new JTextField(20); 
		txtfield5.setEditable(false);
        accountPanel.add(label5);
        accountPanel.add(txtfield5);
        JLabel label6=new JLabel("账户余额："); 
        JTextField txtfield6=new JTextField(10); 
        txtfield6.setEditable(false);
        accountPanel.add(label6);
        accountPanel.add(txtfield6);
        
		
		JLabel label=new JLabel("客户ID：");    
        JComboBox cmb=new JComboBox(); 
        cmb.addItem("--请选择--");
        JLabel accountLabel=new JLabel("账户：");    
        JComboBox accountCmb=new JComboBox();
        accountCmb.addItem("--请选择--");
        
        for(Customer customer:customers) {
        	Long custId = customer.getCustId();
        	String custName = customer.getCustName();
        	cmb.addItem(custName+"("+custId+")");
        }
        cmb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String custInfo =(String) cmb.getSelectedItem();
				if(custInfo==null||"--请选择--".equals(custInfo)) {
					customerInfoPanel.setVisible(false);
					accountPanel.setVisible(false);
					accountCmb.removeAllItems();
					accountCmb.addItem("--请选择--");
					JOptionPane.showMessageDialog(null, "请选择客户", "提示消息", JOptionPane.ERROR_MESSAGE);
					return;
				}
				System.out.println(custInfo);
				Long custId = Long.valueOf(custInfo.substring(custInfo.indexOf("(")+1,custInfo.indexOf(")")));
				for(Customer customer:customers) {
					if(customer.getCustId().compareTo(custId)==0) {
						txtfield1.setText(customer.getCustName());
						txtfield2.setText(customer.getCustId().toString());
						txtfield3.setText(customer.getBirthDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
						txtfield4.setText(new Integer(customer.getAccountList().size()).toString());
						customerInfoPanel.setVisible(true);
						
						accountCmb.removeAllItems();
						accountCmb.addItem("--请选择--");
						for(Account account:customer.getAccountList()) {
							String accountNumber = account.getAccountNumber();
							String type = account.getAccountType();
							accountCmb.addItem(type+" xxx-"+accountNumber.substring(accountNumber.length()-4));
						}
						accountPanel.setVisible(false);
						
					}
				}
			}
		});
        queryPanel.add(label);
        if(queryCustId!=null) {
        	for(int i=0;i<cmb.getItemCount();i++){
        		String item = (String) cmb.getItemAt(i);
        		if(item.indexOf(queryCustId.toString())>0) {
        			cmb.setSelectedIndex(i);
        			break;
        		}
        	}
        }
        queryPanel.add(cmb);
       
        accountCmb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String custInfo =(String) cmb.getSelectedItem();
				String accountNumber =(String) accountCmb.getSelectedItem();
				if(accountNumber==null||"--请选择--".equals(accountNumber)) {
					return;
				}
				System.out.println(custInfo);
				System.out.println(accountNumber);
				Long custId = Long.valueOf(custInfo.substring(custInfo.indexOf("(")+1,custInfo.indexOf(")")));
				String endAccount = accountNumber.split("-")[1];
				for(Customer customer:customers) {
					if(customer.getCustId().compareTo(custId)==0) {
						List<Account> accounts = customer.getAccountList();
						for(Account account:accounts) {
							if(account.getAccountNumber().endsWith(endAccount)) {
								txtfield5.setText(account.getAccountNumber());
								txtfield6.setText(account.getBalance().toString());
								accountPanel.setVisible(true);
							}
						}
					}
				}
			}
		});
        queryPanel.add(accountLabel);
        if(queryAccountNo!=null) {
        	for(int i=1;i<accountCmb.getItemCount();i++){
        		String item = (String) accountCmb.getItemAt(i);
        		String endNo = item.split("-")[1];
        		if(queryAccountNo.endsWith(endNo)) {
        			accountCmb.setSelectedIndex(i);
        			break;
        		}
        	}
        }
        queryPanel.add(accountCmb);
        
        
        JButton transButton = new JButton("交易");
        transButton.setBorderPainted(false);
        transButton.setFocusPainted(false);
        transButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				String custInfo =(String) cmb.getSelectedItem();
				String accountNumber =(String) accountCmb.getSelectedItem();
				System.out.println(custInfo);
				System.out.println(accountNumber);
				Long custId = Long.valueOf(custInfo.substring(custInfo.indexOf("(")+1,custInfo.indexOf(")")));
				String endAccount = accountNumber.split("-")[1];
				for(Customer customer:customers) {
					if(customer.getCustId().compareTo(custId)==0) {
						List<Account> accounts = customer.getAccountList();
						for(Account account:accounts) {
							if(account.getAccountNumber().endsWith(endAccount)) {
								new TransactionPanel(customer.getCustId(),account).setVisible(true);
							}
						}
					}
				}
			}
		});
        accountPanel.add(transButton);
        
        JButton delButton = new JButton("销户");
        delButton.setBorderPainted(false);
        delButton.setFocusPainted(false);
        delButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					for(Customer customer:customers) {
						for(Account account:customer.getAccountList()) {
							if(txtfield5.getText().equals(account.getAccountNumber())) {
								customer.deleteAccount(account);
								customer.getAccountList().remove(account);
								accountCmb.removeItemAt(accountCmb.getSelectedIndex());
								accountPanel.setVisible(false);
								return;
							}
						}
					}
				}catch(Exception ex) {
					JOptionPane.showMessageDialog(null, ex.getMessage(), "提示消息", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
        accountPanel.add(delButton);
        
        JButton delAllButton = new JButton("全部销户");
        delAllButton.setBorderPainted(false);
        delAllButton.setFocusPainted(false);
        delAllButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					for(Customer customer:customers) {
						if(txtfield2.getText().equals(customer.getCustId().toString())) {
							customer.deleteAllAccount(customer);
							accountCmb.removeAllItems();
							accountCmb.addItem("--请选择--");
							accountPanel.setVisible(false);
							break;
						}
					}
				}catch(Exception ex) {
					JOptionPane.showMessageDialog(null, ex.getMessage(), "提示消息", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
        customerInfoPanel.add(delAllButton);
        
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
				gl_contentPane.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_contentPane.createSequentialGroup()
						.addGap(163)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false))
						.addContainerGap(166, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
				gl_contentPane.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_contentPane.createSequentialGroup()
						.addGap(54)
						.addContainerGap(35, Short.MAX_VALUE))
			);
    	
    }

}
