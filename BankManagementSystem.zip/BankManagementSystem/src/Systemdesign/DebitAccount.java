package Systemdesign;

import java.math.BigDecimal;

import systemdesignenum.AccountTypeEnum;
//The class of DebitAccount extends the shared similarities of an account and write its own attributes and methods.
public class DebitAccount extends Account {

    //fields
    private Long card;
    // constructor
    public DebitAccount(String accountNumber, BigDecimal balance, Long card) {
        super(accountNumber, balance);
        this.card = card;
    }
   //getter
    public Long getCard() {
        return card;
    }

    /**
     * 账户类型
     *
     * @return
     */
    //Override the abstract method from Account
    @Override
    public AccountTypeEnum getAccountType() {
        return AccountTypeEnum.debit;
    }

    /**
     * 借方账户不能有负余额，所以任何负金额的交易都需要检查它不会导致余额变为负。如果是这样，则必须拒绝该事务。
     *
     * @throws Exception
     */
    //This is a method to check that debit accounts can’t have a negative balance
    @Override
    public void checkTransAmount(Transaction trans) throws Exception {
        if (this.getBalance().add(trans.getAmount()).compareTo(BigDecimal.ZERO) < 0) {
            throw new Exception("The balance should not be negative");
        }
        super.checkTransAmount(trans);
    }

}

