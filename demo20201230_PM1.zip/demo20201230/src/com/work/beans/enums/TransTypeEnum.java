package com.work.beans.enums;

/**
 *事务类型枚举
 * @author
 *
 */
public enum TransTypeEnum {

    withdrawal("withdrawal","提款"),

    deposit("deposit","存款"),

    transfer("transfer","转账"),

    card("card","刷卡");

    private String transCode;

    private String name;

    TransTypeEnum(String transCode, String name){
        this.transCode = transCode;
        this.name = name;
    }
    
    public String getTransCode() {
        return transCode;
    }

    public String getName() {
        return name;
    }
    
    /**
     * 根据名称查询事务类型
     * @param name
     * @return
     */
    public static TransTypeEnum getTransTypeEnumByName(String name) {
    	for(TransTypeEnum transTypeEnum:TransTypeEnum.values()) {
    		if(transTypeEnum.getName().equals(name)) {
    			return transTypeEnum;
    		}
    	}
    	return null;
    }
    
    /**
     * 根据凑得查询事务类型
     * @param code
     * @return
     */
    public static TransTypeEnum getTransTypeEnumByCode(String code) {
    	for(TransTypeEnum transTypeEnum:TransTypeEnum.values()) {
    		if(transTypeEnum.getTransCode().equals(code)) {
    			return transTypeEnum;
    		}
    	}
    	return null;
    }
}
