package com.dysy.demo.beans;


public enum TransTypeEnum {

    withdrawal("C01","提款"),

    deposit("C02","存款"),

    transfer("C03","转账"),

    card("C04","刷卡");

    private String transCode;

    private String description;

    public String getTransCode() {
        return transCode;
    }

    public void setTransCode(String transCode) {
        this.transCode = transCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    TransTypeEnum(String transCode, String description){
        this.transCode = transCode;
        this.description = description;
    }
}
