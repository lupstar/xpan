package Systemdesign;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import systemdesignenum.AccountTypeEnum;
import systemdesignenum.TransTypeEnum;
//The class of SavingsAccount extends the shared similarities of an account and write its own attributes and methods.
public class SavingsAccount extends Account {

    //field: saving account has an interest rate;
    private  BigDecimal interestRate;
    //constructor
    public SavingsAccount(String accountNumber, BigDecimal balance, BigDecimal interestRate) {
        super(accountNumber, balance);
        this.interestRate = interestRate;
    }
    //getter
    public BigDecimal getInterestRate() {
        return interestRate;
    }
    //override the abstract method of Account
    @Override
    public AccountTypeEnum getAccountType() {
        return AccountTypeEnum.savings;
    }

    /**
     * 储蓄账户不支持银行卡交易或取款。它们允许有存款和转账
     *
     * @return
     */
    //This is a method telling that Savings account only support deposti transactions or transfer.
    @Override
    public List<TransTypeEnum> getTransFunction() {
        List<TransTypeEnum> transTypeEnumList = new ArrayList<>();
        transTypeEnumList.add(TransTypeEnum.deposit);
        transTypeEnumList.add(TransTypeEnum.transfer);
        return transTypeEnumList;
    }

    /**
     * 储蓄账户允许有正数的存款和转账
     *
     * @throws Exception
     */
    // this is method to ensure that savings account only allow deposits and transfers with a positive amount.
    @Override
    public void checkTransAmount(Transaction trans) throws Exception {
        if (trans.getAmount().compareTo(BigDecimal.ZERO) < 0) {
            throw new Exception("Savings account only allow deposits and transfers with a positive amount.");
        }
    }
    // this is method to say that when customer try to carry out withdrawal transaction, the system would reject it;
    @Override
    public void withdralAccount(Transaction trans) throws Exception {
        throw new Exception("Savings account don’t support withdrawal transactions");
    }
    //this is method to say that when customer try to carry out card transaction, the system would reject it;
    @Override
    public void useCard(Transaction trans) throws Exception {
        throw new Exception("Savings account don’t support card transactions");
    }
}
