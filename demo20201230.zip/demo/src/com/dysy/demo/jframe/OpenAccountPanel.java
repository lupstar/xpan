package com.dysy.demo.jframe;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;

import javax.swing.AbstractButton;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.dysy.demo.beans.Account;
import com.dysy.demo.beans.AccountTypeEnum;
import com.dysy.demo.beans.Customer;
import com.dysy.demo.dataload.FileReaderAndWrite;

public class OpenAccountPanel extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    OpenAccountPanel frame = new OpenAccountPanel(null);
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public OpenAccountPanel(Customer customer) {
    	JPanel contentPane = new JPanel();
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 400);
    	contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
		contentPane.setForeground(Color.LIGHT_GRAY);
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		setContentPane(contentPane);
		
		final JPanel queryPanel = new JPanel();
		queryPanel.setBounds(100, 100, 800, 100);
		queryPanel.setForeground(Color.LIGHT_GRAY);
		queryPanel.setBackground(new Color(248, 248, 255));
		queryPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		getContentPane().add(queryPanel);
		contentPane.add(queryPanel);
		
		final JPanel buttonPanel = new JPanel();
		buttonPanel.setBounds(100, 100, 800, 100);
		buttonPanel.setForeground(Color.LIGHT_GRAY);
		buttonPanel.setBackground(new Color(248, 248, 255));
		buttonPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		getContentPane().add(buttonPanel);
		contentPane.add(buttonPanel);
		
		ButtonGroup group=new ButtonGroup();
		JLabel label=new JLabel("请选择账户类型：");
		contentPane.add(label);
		queryPanel.add(label);
		for(AccountTypeEnum accountType:Arrays.asList(AccountTypeEnum.values())) {
			JRadioButton rb=new JRadioButton(accountType.getDescription()); 
			group.add(rb);
			queryPanel.add(rb);
		}
		
		JLabel label1=new JLabel("开户预存金额："); 
		final JTextField txtfield1=new JTextField(10); 
        queryPanel.add(label1);
        queryPanel.add(txtfield1);
		
        JButton openButton = new JButton("开户");
        openButton.setBorderPainted(false);
        openButton.setFocusPainted(false);
        openButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					BigDecimal amount = BigDecimal.ZERO;
					if(txtfield1.getText()!=null&&!"".equals(txtfield1.getText())) {
						amount = new BigDecimal(txtfield1.getText());
					}
					String selectedTxt=null;
					Enumeration<AbstractButton> radioBtns=group.getElements();
					while (radioBtns.hasMoreElements()) {
						AbstractButton btn = radioBtns.nextElement();
						if(btn.isSelected()){
							selectedTxt=btn.getText();
							break;
						}
					}
					if(selectedTxt==null||"".equals(selectedTxt)) {
						throw new Exception("请选择一种账户类型");
					}
					for(AccountTypeEnum accountTypeEnum:Arrays.asList(AccountTypeEnum.values())) {
						if(accountTypeEnum.getDescription().equals(selectedTxt)) {
							customer.openAccount(accountTypeEnum, amount);
						}
					}
					dispose();
					new CustomerPanel(new JPanel(),customer.getCustId(),null).setVisible(true);
				}catch(Exception ex) {
					JOptionPane.showMessageDialog(null, ex.getMessage(), "提示消息", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
        buttonPanel.add(openButton);
        
        JButton exitButton = new JButton("返回");
		exitButton.setBorderPainted(false);
		exitButton.setFocusPainted(false);
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				new CustomerPanel(new JPanel(),customer.getCustId(),null).setVisible(true);
			}
		});
		buttonPanel.add(exitButton);
        
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
				gl_contentPane.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_contentPane.createSequentialGroup()
						.addGap(163)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false))
						.addContainerGap(166, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
				gl_contentPane.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_contentPane.createSequentialGroup()
						.addGap(54)
						.addContainerGap(35, Short.MAX_VALUE))
			);
    	
    }

}
