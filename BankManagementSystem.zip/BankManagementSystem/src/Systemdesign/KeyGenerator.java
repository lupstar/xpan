package Systemdesign;

import fileOperation.FileReadAndWrite;
// The class KeyGenerator is used to define the card attribute and account number
public class KeyGenerator {

    private static Long cardId = null;

    private static Long ibanNo = null;
    // this is a method of defining card attribute 
    public static Long getCardIdKey() throws Exception {
        synchronized (KeyGenerator.class) {
            String key = FileReadAndWrite.getCurrentKeys("cardId");
            cardId = Long.valueOf(key);
        }
        return cardId;
    }
    // this is a method of defining account number
    public static String getIbanKey() throws Exception {
        String iban;
        synchronized (KeyGenerator.class) {
            String prefix = "GB";
            String checkIn = "98";
            String key = FileReadAndWrite.getCurrentKeys("iban");
            ibanNo = Long.valueOf(key);
            String endfix = "MIDL" + ibanNo;
            iban = prefix + checkIn + endfix;
        }
        return iban;
    }

}

