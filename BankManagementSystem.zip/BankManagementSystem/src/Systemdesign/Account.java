package Systemdesign;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import base.TransactionOperation;
import systemdesignenum.AccountTypeEnum;
import systemdesignenum.TransTypeEnum;
import fileOperation.FileReadAndWrite;
//This is an abstract class Account used to factor out similarities of three specific accounts: debit,savings,credit.
public abstract class Account implements TransactionOperation {
    //fields
    private String accountNumber;

    private BigDecimal balance;
    //constructor
    public Account(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public Account(String accountNumber, BigDecimal balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    /**
     * account type
     *
     * @return
     */
    
   
    ////getters
    public String getAccountNumber() {
        return accountNumber;
    }

    public BigDecimal getBalance() {
        return balance;
    }
    //abstract method
     public abstract AccountTypeEnum getAccountType();
    
    
    
    //override the method from the interface of TransactionOperation
    @Override
    public void withdralAccount(Transaction trans) throws Exception {
        this.checkTransAmount(trans);

        List<TransTypeEnum> transTypeEnumList = this.getTransFunction();
        //if the account can support withdrwal transaction, then can query customer by account number, and modify and record transaction record;
        if (transTypeEnumList.contains(TransTypeEnum.withdrawal)) {
            Customer customer = this.queryCustomerByAccountNumber(accountNumber);
            FileReadAndWrite.writeAccount(this, customer.getCustId(), trans, null);
            FileReadAndWrite.writeTransRecord(this, customer.getCustId(), trans);
          } 
        // if the account cannot support withdraw transaction, a exception would be throwed and remind that "the transaction is not allowed"
        else {
            throw new Exception("The transaction is not allowed");
        }
    }
    //override the method from the interface of TransactionOperation
    @Override
    public void depositAccount(Transaction trans) throws Exception {
        this.checkTransAmount(trans);

        List<TransTypeEnum> transTypeEnumList = this.getTransFunction();
         //if the account can support deposit transaction, then can query customer by account number, and modify and record transaction record;
        if (transTypeEnumList.contains(TransTypeEnum.deposit)) {
            Customer customer = this.queryCustomerByAccountNumber(accountNumber);
            FileReadAndWrite.writeAccount(this, customer.getCustId(), trans, null);
            FileReadAndWrite.writeTransRecord(this, customer.getCustId(), trans);
         
        } 
        // if the account cannot support deposit transaction, a exception would be throwed and remind that "the transaction is not allowed"
        else {
            throw new Exception("The transaction is not allowed");
        }
    }

    @Override
    public void transferAccount(Transaction trans, String transferAccountNo) throws Exception {
        this.checkTransAmount(trans);
        // transferCustomer is needed when in transfer transaction
        Customer transferCustomer = this.queryCustomerByAccountNumber(transferAccountNo);
        if (transferCustomer == null) {
            throw new Exception("TransferAccount[" + transferCustomer + "]is not exist！");
        }
        //转入账户操作
        //the operation of transfer into the account
        for (Account transAccount : transferCustomer.getAccountList()) {
            if (transAccount.getAccountNumber().equals(transferAccountNo)) {
                Transaction transferTrans = new Transaction(trans.getTransId(), TransTypeEnum.transfer, BigDecimal.ZERO.subtract(trans.getAmount()));
                transAccount.tranSingleAccountOper(transferTrans);
            }
        }
        
        //本人账户转账操作The operation of transfer out of the account 
        this.tranSingleAccountOper(trans);
    }
   //override the method from the interface of TransactionOperation
    @Override
    public void useCard(Transaction trans) throws Exception {
        this.checkTransAmount(trans);
        
        List<TransTypeEnum> transTypeEnumList = this.getTransFunction();
        //if the account can support card transaction, then can query customer by account number, and modify and record transaction record;
        if (transTypeEnumList.contains(TransTypeEnum.card)) {
            Customer customer = this.queryCustomerByAccountNumber(accountNumber);
            FileReadAndWrite.writeAccount(this, customer.getCustId(), trans, null);
            FileReadAndWrite.writeTransRecord(this, customer.getCustId(), trans);
        } 
         // if the account cannot support card transaction, a exception would be throwed and remind that "the transaction is not allowed"
        else {
            throw new Exception("The transaction is not allowed");
        }
    }

    /**
     * 账户所拥有的所有功能事务
     *
     * @return
     */
    // get the four functions of transaction
    public List<TransTypeEnum> getTransFunction() {
        return Arrays.asList(TransTypeEnum.values());
    }

    /**
     * 基本金额校验
     *
     * @param trans
     * @throws Exception
     */
    //This is a method for checking validation of the transaction amount of withdrawal and deposit
    public void checkTransAmount(Transaction trans) throws Exception {
        // the amount of a withdrawal must be negative
        if (TransTypeEnum.withdrawal.getTransCode().equals(trans.getTransType().getTransCode())) {
            if (trans.getAmount().compareTo(BigDecimal.ZERO) > 0) {
                throw new Exception("The amount of a withdrawal must be negative");
            }
            // the amount of a deposit must be positive
        } else if (TransTypeEnum.deposit.getTransCode().equals(trans.getTransType().getTransCode())) {
            if (trans.getAmount().compareTo(BigDecimal.ZERO) < 0) {
                throw new Exception(" The amount of a deposit must be positive");
            }
        }
    }

    /**
     * 根据账户号查询所属用户
     *
     * @param accountNumber
     * @return
     * @throws Exception
     */
    //this is a method used to query customer by account number
    public Customer queryCustomerByAccountNumber(String accountNumber) throws Exception {
        
        List<Customer> customers = new ArrayList<>();
        FileReadAndWrite.loadData(customers);
        for (Customer customer : customers) {
            for (Account account : customer.getAccountList()) {
                if (account.getAccountNumber().equals(accountNumber)) {
                    return customer;
                }
            }
        }
        throw new Exception("account number【" + accountNumber + "】is not exist");
    }

    /**
     * 转账双方中一方账户操作
     *
     * @param trans
     * @throws Exception
     */
    //this is a method of the operation of tranferee and transferor in transfer transaction
    private void tranSingleAccountOper(Transaction trans) throws Exception {
        this.checkTransAmount(trans);

        List<TransTypeEnum> transTypeEnumList = this.getTransFunction();
        if (transTypeEnumList.contains(TransTypeEnum.transfer)) {
            Customer customer = this.queryCustomerByAccountNumber(accountNumber);
            FileReadAndWrite.writeAccount(this, customer.getCustId(), trans, null);
            FileReadAndWrite.writeTransRecord(this, customer.getCustId(), trans);
        } else {
            throw new Exception("The transaction is not allowed");
        }
    }

}
