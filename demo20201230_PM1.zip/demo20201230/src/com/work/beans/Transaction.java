package com.work.beans;

import java.math.BigDecimal;
import java.util.UUID;

import com.work.beans.enums.TransTypeEnum;

/**
 * 事务实体
 * @author 
 *
 */
public class Transaction {

	//事务Id:字母数字引用
    private String transId;
    //事务类型
    private TransTypeEnum transType;
    //数量（金额）
    private BigDecimal amount;
    
    public Transaction(TransTypeEnum transType,BigDecimal amount) {
    	this.transId = UUID.randomUUID().toString().replace("-", "");
    	this.transType = transType;
    	this.amount = amount;
    }
    
    public Transaction(String transId,TransTypeEnum transType,BigDecimal amount) {
    	this.transId = transId;
    	this.transType = transType;
    	this.amount = amount;
    }

    public String getTransId() {
        return transId;
    }

    public TransTypeEnum getTransType() {
        return transType;
    }

    public BigDecimal getAmount() {
        return amount;
    }

}
