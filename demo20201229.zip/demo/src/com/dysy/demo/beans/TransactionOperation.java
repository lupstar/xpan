package com.dysy.demo.beans;

public interface TransactionOperation {

    public void withdralAccount(Transaction trans) throws Exception;

    public void depositAccount(Transaction trans) throws Exception;

    public void transferAccount(Transaction trans) throws Exception;

    public void useCard(Transaction trans) throws Exception;

}
