package Systemdesign;

import java.math.BigDecimal;
import java.util.UUID;

import systemdesignenum.TransTypeEnum;

/**
 * 事务实体
 *
 * @author
 *
 */
//
public class Transaction {
     
    //fields
    private String transId;
    private TransTypeEnum transType;
    private BigDecimal amount;
    //constructors
    public Transaction(TransTypeEnum transType, BigDecimal amount) {
        this.transId = UUID.randomUUID().toString().replace("-", "");
        this.transType = transType;
        this.amount = amount;
    }
    
    public Transaction(String transId, TransTypeEnum transType, BigDecimal amount) {
        this.transId = transId;
        this.transType = transType;
        this.amount = amount;
    }
    // getter
    public String getTransId() {
        return transId;
    }

    public TransTypeEnum getTransType() {
        return transType;
    }

    public BigDecimal getAmount() {
        return amount;
    }

}

