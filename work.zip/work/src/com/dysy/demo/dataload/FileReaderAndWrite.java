package com.dysy.demo.dataload;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.dysy.demo.beans.Account;
import com.dysy.demo.beans.CreditAccount;
import com.dysy.demo.beans.Customer;
import com.dysy.demo.beans.DebitAccount;
import com.dysy.demo.beans.SavingsAccount;


public class FileReaderAndWrite {
    
	public static void loadData(List<Customer> customers) throws Exception {
		FileReaderAndWrite.loadCustomers(customers);
        FileReaderAndWrite.loadCreditAccounts(customers);
        FileReaderAndWrite.loadDebitAccounts(customers);
        FileReaderAndWrite.loadSavingsAccounts(customers);
	}
	
    public static void loadCustomers(List<Customer> customers) throws Exception {
        String path = new File("file/database/customers.csv").getCanonicalPath();
        File file = new File(path);
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new java.io.FileReader(file));
            String strLine = null;
            while(null != (strLine = bufferedReader.readLine())){
                String[] dataLine = strLine.split(",");
                Customer customer = new Customer();
                customer.setCustName(dataLine[0]);
                customer.setCustId(Long.valueOf(dataLine[1]));
                customer.setBirthDate(LocalDate.parse(dataLine[2]));
                customers.add(customer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try{
                if(bufferedReader!=null){
                    bufferedReader.close();
                }
            }catch (IOException ioe){
                ioe.printStackTrace();
            }
        }
    }
    
    public static void loadCreditAccounts(List<Customer> customers) throws Exception {
        String path = new File("file/database/credit_accounts.csv").getCanonicalPath();
        File file = new File(path);
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new java.io.FileReader(file));
            String strLine = null;
            while(null != (strLine = bufferedReader.readLine())){
                String[] dataLine = strLine.split(",");
                String custId = dataLine[0];
                for(Customer customer:customers){
                	if(customer.getCustId().toString().equals(custId)) {
                		CreditAccount creditAccount = new CreditAccount();
                        creditAccount.setAccountNumber(dataLine[1]);
                        creditAccount.setBalance(new BigDecimal(dataLine[2]));
                        creditAccount.setCard(Long.valueOf(dataLine[3]));
                        List<Account> accounts = customer.getAccountList();
                        if(accounts.size()<5) {
                        	accounts.add(creditAccount);
                        }else {
                        	throw new Exception("account lager than five...");
                        }
                	}
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try{
                if(bufferedReader!=null){
                    bufferedReader.close();
                }
            }catch (IOException ioe){
                ioe.printStackTrace();
            }
        }
    }
    
    public static void loadDebitAccounts(List<Customer> customers) throws Exception {
        String path = new File("file/database/debit_accounts.csv").getCanonicalPath();
        File file = new File(path);
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new java.io.FileReader(file));
            String strLine = null;
            while(null != (strLine = bufferedReader.readLine())){
                String[] dataLine = strLine.split(",");
                String custId = dataLine[0];
                for(Customer customer:customers){
                	if(customer.getCustId().toString().equals(custId)) {
                		DebitAccount debitAccount = new DebitAccount();
                		debitAccount.setAccountNumber(dataLine[1]);
                		debitAccount.setBalance(new BigDecimal(dataLine[2]));
                		debitAccount.setCard(Long.valueOf(dataLine[3]));
                		List<Account> accounts = customer.getAccountList();
                        if(accounts.size()<5) {
                        	accounts.add(debitAccount);
                        }else {
                        	throw new Exception("account lager than five...");
                        }
                	}
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try{
                if(bufferedReader!=null){
                    bufferedReader.close();
                }
            }catch (IOException ioe){
                ioe.printStackTrace();
            }
        }
    }
    
    
    public static void loadSavingsAccounts(List<Customer> customers) throws Exception {
        String path = new File("file/database/savings_accounts.csv").getCanonicalPath();
        File file = new File(path);
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new java.io.FileReader(file));
            String strLine = null;
            while(null != (strLine = bufferedReader.readLine())){
                String[] dataLine = strLine.split(",");
                String custId = dataLine[0];
                for(Customer customer:customers){
                	if(customer.getCustId().toString().equals(custId)) {
                		SavingsAccount savingsAccount = new SavingsAccount();
                		savingsAccount.setAccountNumber(dataLine[1]);
                		savingsAccount.setBalance(new BigDecimal(dataLine[2]));
                		savingsAccount.setInterestRate(null);
                		List<Account> accounts = customer.getAccountList();
                        if(accounts.size()<5) {
                        	accounts.add(savingsAccount);
                        }else {
                        	throw new Exception("account lager than five...");
                        }
                	}
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try{
                if(bufferedReader!=null){
                    bufferedReader.close();
                }
            }catch (IOException ioe){
                ioe.printStackTrace();
            }
        }
    }
    
    
    public static void writeAccount(Account account,String custId,String operateType) throws Exception {
    	String path = "";
        String appendLine="";
    	if(account instanceof com.dysy.demo.beans.CreditAccount) {
    		path = new File("file/database/credit_accounts.csv").getCanonicalPath();
    		appendLine = custId+","+account.getAccountNumber()+","+account.getBalance()+","+((CreditAccount) account).getCard() +"\n";
    	}else if(account instanceof com.dysy.demo.beans.DebitAccount) {
    		path = new File("file/database/debit_accounts.csv").getCanonicalPath();
    		appendLine = custId+","+account.getAccountNumber()+","+account.getBalance()+","+((DebitAccount) account).getCard() +"\n";
    	}else if(account instanceof com.dysy.demo.beans.SavingsAccount) {
    		path = new File("file/database/savings_accounts.csv").getCanonicalPath();
    		appendLine = custId+","+account.getAccountNumber()+","+account.getBalance()+"\n";
    	}
        File file = new File(path);
        BufferedReader bufferedReader = null;
        PrintWriter pw=new PrintWriter(path);
        try {
        	StringBuffer content = new StringBuffer("");
            bufferedReader = new BufferedReader(new java.io.FileReader(file));
            String strLine = null;
            while(null != (strLine = bufferedReader.readLine())){
                String[] dataLine = strLine.split(",");
                String flieCustId = dataLine[0];
                if(flieCustId.equals(custId)&&account.getAccountNumber().equals(dataLine[1])) {
                	if("del".equals(operateType)) {
                		continue;
                	} else if("upd".equals(operateType)){
                		content.append(appendLine);
                		continue;
                	}
                }
                content.append(strLine);
            }
            if("add".equals(operateType)) {
            	content.append(appendLine);
            }
            pw.write(content.toString());
            pw.flush();
            pw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try{
                if(bufferedReader!=null){
                    bufferedReader.close();
                }
                if(pw!=null) {
                	pw.close();
                }
            }catch (IOException ioe){
                ioe.printStackTrace();
            }
        }
    }
    

    public static void main(String[] args) throws Exception {
        List<Customer> customers = new ArrayList<>();
        FileReaderAndWrite.loadCustomers(customers);
        FileReaderAndWrite.loadCreditAccounts(customers);
        FileReaderAndWrite.loadDebitAccounts(customers);
        FileReaderAndWrite.loadSavingsAccounts(customers);
        System.out.println(customers);
    }

}
