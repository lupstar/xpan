package com.dysy.demo;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class InitUserSurface extends JFrame {

	private JPanel contentPane;//底层面板，创建用户业务选择面板时调用
	private static long preMoney = 0;//储存用户原先的余额,用户存款和取款时调用

	/**
	 * 启动应用
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InitUserSurface frame = new InitUserSurface();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * 创建用户登录后的界面
	 */
	public InitUserSurface() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(700, 300, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		setContentPane(contentPane);
		
		JButton seekButton = new JButton("\u4F59\u989D\u67E5\u8BE2");//余额查询按钮
		seekButton.setBackground(new Color(204, 204, 255));
		seekButton.setBorderPainted(false);//设置按钮边框不可见
		seekButton.setFocusPainted(false);//当点击按钮时不出现边框
		//给查询按钮添加事件处理
		seekButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(int i = 0;i < InitMainFrame.list.size();i++)
				{
					if(InitUserLoginSurface.userAccount.equals(InitMainFrame.list.get(i).getAccount()))
					{
						JOptionPane.showMessageDialog(null,"当前余额:"+InitMainFrame.list.get(i).getMoney(),"提示消息",JOptionPane.INFORMATION_MESSAGE);
						preMoney = InitMainFrame.list.get(i).getMoney();
						break;
					}
				}
			}
		});
		
		JButton storeButton = new JButton("\u5B58    \u6B3E");//存款按钮
		storeButton.setBackground(new Color(135, 206, 250));
		storeButton.setBorderPainted(false);
		storeButton.setFocusPainted(false);
		//给存款按钮添加事件处理
		storeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cash = JOptionPane.showInputDialog(null, "输入存款金额", "存款", JOptionPane.INFORMATION_MESSAGE);
				long money = 0;
				try {
					money = Long.parseLong(cash);//将String转化为Long
				} catch (NumberFormatException e1) {
					
				}
				for(int i = 0;i < InitMainFrame.list.size();i++)
				{
					if(InitUserLoginSurface.userAccount.equals(InitMainFrame.list.get(i).getAccount()))
					{
						if(money <= 0)
							JOptionPane.showMessageDialog(null,"请输入正确的金额","提示消息",JOptionPane.ERROR_MESSAGE);
						else
						{
							JOptionPane.showMessageDialog(null,"存款成功","提示消息",JOptionPane.INFORMATION_MESSAGE);
							InitMainFrame.list.get(i).setMoney(money+preMoney);
						}
						
					}
					
				}
			}
		});
		
		JButton takeButton = new JButton("\u53D6    \u6B3E");//取款按钮
		takeButton.setBackground(new Color(221, 160, 221));
		takeButton.setForeground(new Color(0, 0, 0));
		takeButton.setBorderPainted(false);
		takeButton.setFocusPainted(false);
		takeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cash = JOptionPane.showInputDialog(null, "输入取款金额", "取款", JOptionPane.INFORMATION_MESSAGE);
				long money = 0;
				try {
					money = Long.parseLong(cash);
				} catch (NumberFormatException e1) {
					
				}
				for(int i = 0;i < InitMainFrame.list.size();i++)
				{
					if(InitUserLoginSurface.userAccount.equals(InitMainFrame.list.get(i).getAccount()))
					{
						if(money > InitMainFrame.list.get(i).getMoney() || money <= 0)
							JOptionPane.showMessageDialog(null,"余额不足，取款失败","提示消息",JOptionPane.ERROR_MESSAGE);
						else
						{
							if(money % 100 != 0 || money > 5000)
							{
								JOptionPane.showMessageDialog(null,"取款金额必须是100的倍数，且不能超过5000","提示消息",JOptionPane.ERROR_MESSAGE);
							}
							else
							{
								JOptionPane.showMessageDialog(null,"取款成功","提示消息",JOptionPane.INFORMATION_MESSAGE);
								InitMainFrame.list.get(i).setMoney(preMoney-money);
							}
								
						}
						
					}
					
				}
			}
		});
		
		JButton changeCodeButton = new JButton("\u4FEE\u6539\u5BC6\u7801");//修改密码按钮
		changeCodeButton.setBackground(new Color(153, 255, 204));
		changeCodeButton.setBorderPainted(false);
		changeCodeButton.setFocusPainted(false);
		//给修改密码按钮添加事件处理
		changeCodeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ChangePassword changePassword = new ChangePassword();
				changePassword.setVisible(true);
			}
		});
		
		JButton exitButton = new JButton("\u9000\u51FA");//退出按钮
		exitButton.setBackground(new Color(255, 204, 153));
		exitButton.setBorderPainted(false);
		exitButton.setFocusPainted(false);
		//给退出按钮添加事件处理
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InitMainFrame.userFile.saveFile(InitMainFrame.list);
				for(int i = 0;i < InitMainFrame.list.size();i++)
				{
					System.out.println(InitMainFrame.list.get(i));
				}
				dispose();
				InitMainFrame mainFrame = new InitMainFrame();
				mainFrame.setVisible(true);
							
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addGap(176)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(exitButton, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
						.addComponent(changeCodeButton, GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
						.addComponent(takeButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(storeButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(seekButton, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE))
					.addGap(167))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(27)
					.addComponent(seekButton)
					.addGap(18)
					.addComponent(storeButton)
					.addGap(30)
					.addComponent(takeButton)
					.addGap(18)
					.addComponent(changeCodeButton)
					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addComponent(exitButton)
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
	}
}
