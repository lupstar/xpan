package com.dysy.demo.beans;

import com.dysy.demo.dataload.FileReaderAndWrite;

public class KeyGenerator {
	
	private static Long cardId = null;
	
	private static Long ibanNo = null;
	
	public static Long getCardIdKey() throws Exception {
		synchronized(KeyGenerator.class) {
			String key = FileReaderAndWrite.getCurrentKeys("cardId");
			cardId = Long.valueOf(key);
		}
		return cardId;
	}
	
	public static String getIbanKey() throws Exception {
		String iban ="";
		synchronized(KeyGenerator.class) {
			String prefix = "GB";
			String checkIn = "98";
			String key = FileReaderAndWrite.getCurrentKeys("iban");
			System.out.println(key);
			ibanNo = Long.valueOf(key);
			String endfix = "MIDL"+ibanNo;
			iban = prefix+checkIn+endfix;
		}
		return iban;
	}
	

}
