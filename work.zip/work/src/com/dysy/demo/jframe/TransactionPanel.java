package com.dysy.demo.jframe;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.dysy.demo.beans.Account;

public class TransactionPanel extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	/**
	 * 启动应用
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TransactionPanel frame = new TransactionPanel(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

    
	public TransactionPanel(Account account) {
    	
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 400);
    	
    	JPanel contentPane = new JPanel();
    	contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
		contentPane.setForeground(Color.LIGHT_GRAY);
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		setContentPane(contentPane);
		
		//客户查询面板
		final JPanel queryPanel = new JPanel();
		queryPanel.setBounds(100, 100, 800, 100);
		queryPanel.setForeground(Color.LIGHT_GRAY);
		queryPanel.setBackground(new Color(248, 248, 255));
		queryPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		getContentPane().add(queryPanel);
		contentPane.add(queryPanel);
		
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
				gl_contentPane.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_contentPane.createSequentialGroup()
						.addGap(163)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false))
						.addContainerGap(166, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
				gl_contentPane.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_contentPane.createSequentialGroup()
						.addGap(54)
						.addContainerGap(35, Short.MAX_VALUE))
			);
    	
    }


}
