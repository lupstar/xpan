package com.dysy.demo.beans;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CreditAccount extends Account {
	
	//信用卡属性
    private Long card;
    
    public CreditAccount(String accountNumber, BigDecimal balance, Long card) {
		super(accountNumber, balance);
		this.card = card;
	}

    public Long getCard() {
        return card;
    }
    
    @Override
    public AccountTypeEnum getAccountType() {
    	return AccountTypeEnum.credit;
    }

}
