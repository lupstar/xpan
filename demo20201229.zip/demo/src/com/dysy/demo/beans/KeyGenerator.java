package com.dysy.demo.beans;

public class KeyGenerator {
	
	private static Long cardId = 1000000000000001l;
	
	private static Long IBAN_CardNo = 10000000000000l;
	
	public static Long getCardIdKey() {
		synchronized(cardId) {
			cardId++;
		}
		return cardId;
	}
	
	public static String getIbanCardNoKey() {
		String iban ="";
		synchronized(cardId) {
			String prefix = "GB";
			String checkIn = "98";
			IBAN_CardNo = ++IBAN_CardNo;
			String endfix = "MIDL"+IBAN_CardNo;
			iban = prefix+checkIn+endfix;
		}
		return iban;
	}
	

}
