package systemdesignenum;
//This enum class is used to define account types 
public enum AccountTypeEnum {
     // Account types
    credit("Credit", "借方"),
    debit("Debit", "贷方"),
    savings("Savings", "储蓄");
    
    //fields
    private String accountType;

    private String description;
     //constructor
    AccountTypeEnum(String accountType, String description) {
        this.accountType = accountType;
        this.description = description;
    }
   //getters
    public String getAccountType() {
        return accountType;
    }

    public String getDescription() {
        return description;
    }
   
}
