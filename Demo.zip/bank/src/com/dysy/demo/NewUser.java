package com.dysy.demo;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;

public class NewUser extends JFrame {

	private static final long serialVersionUID = 1L;//作用是序列化时保持版本的兼容性，即在版本升级时反序列化仍保持对象的唯一性
	private JPanel contentPane;//底层面板
	private JPasswordField firstMima;//第一次输入的密码
	private JLabel secondMimaLabel;//第二次输入的密码标签
	private JPasswordField secondMima;//第二次输入的密码
	private JLabel infoLabel;//提示第二次输入的密码是否正确
	private JButton cancelButton;//取消按钮

	/**
	 * 启动应用
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewUser frame = new NewUser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * 创建开户界面
	 */
	public NewUser() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(700, 300, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel firstMimaLabel = new JLabel("\u8F93\u5165\u5BC6\u7801");//第一次输入密码的标签
		firstMimaLabel.setFont(new Font("宋体", Font.PLAIN, 18));
		firstMimaLabel.setBounds(50, 66, 81, 18);
		contentPane.add(firstMimaLabel);
		
		firstMima = new JPasswordField();
		firstMima.setFont(new Font("宋体", Font.PLAIN, 18));
		firstMima.setBounds(145, 63, 180, 24);
		firstMima.setOpaque(false);
		contentPane.add(firstMima);
		
		secondMimaLabel = new JLabel("\u786E\u8BA4\u5BC6\u7801");
		secondMimaLabel.setFont(new Font("宋体", Font.PLAIN, 18));
		secondMimaLabel.setBounds(50, 110, 72, 18);
		contentPane.add(secondMimaLabel);
		
		secondMima = new JPasswordField();
		secondMima.setFont(new Font("宋体", Font.PLAIN, 18));
		secondMima.setBounds(145, 109, 180, 24);
		secondMima.setOpaque(false);
		contentPane.add(secondMima);
		
		infoLabel = new JLabel("\u5BC6\u7801\u6709\u8BEF");
		infoLabel.setForeground(Color.RED);
		infoLabel.setBounds(339, 112, 72, 18);
		infoLabel.setVisible(false);
		contentPane.add(infoLabel);
		
		JButton registerButton = new JButton("\u6CE8\u518C");//注册按钮
		
		registerButton.setBackground(new Color(175, 238, 238));
		registerButton.setBorderPainted(false);
		registerButton.setFocusPainted(false);
		
		firstMima.addKeyListener(new PasswordText());
		
		secondMima.addKeyListener(new PasswordText());
		
		registerButton.addActionListener(new registerButtonHandler(firstMima,secondMima));
		registerButton.setBounds(145, 172, 69, 27);
		
		contentPane.add(registerButton);
		
		JLabel openNewUserLabel = new JLabel("\u5F00    \u6237");//开户标签
		openNewUserLabel.setForeground(new Color(0, 191, 255));
		openNewUserLabel.setFont(new Font("宋体", Font.PLAIN, 18));
		openNewUserLabel.setBounds(180, 13, 72, 18);
		contentPane.add(openNewUserLabel);
		
		cancelButton = new JButton("\u53D6\u6D88");
		cancelButton.setBackground(new Color(240, 248, 255));
		cancelButton.setBorderPainted(false);
		cancelButton.setFocusPainted(false);
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		cancelButton.setBounds(256, 172, 69, 27);
		contentPane.add(cancelButton);
	}
	
	/**
	 * 给密码框添加键盘事件，使其只能输入数字
	 */
	public class PasswordText extends KeyAdapter{
		public void keyTyped(KeyEvent e) {
			int key=e.getKeyChar();
			
			if((!(key >= KeyEvent.VK_0 && key <= KeyEvent.VK_9)))
			{
				e.consume();
			}
		}
	}
	
	/**
	 * 给注册按钮添加事件处理
	 */
	public class registerButtonHandler implements ActionListener{
		private JPasswordField firstMima;//第一次输入的密码
		private JPasswordField secondMima;//第二次输入的密码
		
		/**
		 * @param firstMima
		 * @param secondMima
		 */
		public registerButtonHandler(JPasswordField firstMima,JPasswordField secondMima) {
			this.firstMima = firstMima;
			this.secondMima = secondMima;
		}
		
		/*
		 * 实现ActionListener的actionPerformed()方法
		 */
		public void actionPerformed(ActionEvent e){
			int sameChar = 0;//密码中相同字符的个数
			char[] mimaChar = new String(firstMima.getPassword()).toCharArray();//将字符串转化为字符数组
			
			for(int j = 0;j < new String(firstMima.getPassword()).length();j++)
			{
				if(mimaChar[j] == mimaChar[0])
					sameChar++;
			}
			
			if(new String(firstMima.getPassword()).length() != 6 || sameChar == 6)
			{
				JOptionPane.showMessageDialog(null,"密码长度必须是6位不完全相同的数字，请重新输入","提示消息",JOptionPane.ERROR_MESSAGE);
			}
			else
			{
				if(new String(firstMima.getPassword()).equals(new String(secondMima.getPassword()))) 
				{
					
					infoLabel.setVisible(false);
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-ddHH:mm:ss:SSS");//日期的格式
					String time = sdf.format(new Date());//获取当前时间
					String delTime = time.replaceAll("-", "");//删除字符串中的"-"
					String reDelTime = delTime.replaceAll(":", "");//删除字符串中的":"
					StringBuilder account = new StringBuilder(reDelTime);//删除符号后得到的账号
					account.replace(reDelTime.length()-1, reDelTime.length(),"");//删除账号的最后一位
					String mima = new String(firstMima.getPassword()) + "0";
					String ac = account + "";
					
					System.out.println("时间:"+time);
					System.out.println("卡号:"+ac);
					System.out.println("密码:"+mima);
					
					JOptionPane.showMessageDialog(null,"开户成功，你的卡号:"+account,"提示消息",JOptionPane.INFORMATION_MESSAGE);
					UserInfo user = new UserInfo();
					user.setAccount(ac);
					user.setPassword(mima);
					user.setMoney(0);
					InitMainFrame.list.add(user);
					InitMainFrame.userFile.saveFile(InitMainFrame.list);
					
					for(int i = 0;i < InitMainFrame.list.size();i++)
					{
						System.out.println(InitMainFrame.list.get(i));
					}
					dispose();
				}
				else
				{
					infoLabel.setVisible(true);
				}
			}
		}
	}
}