package com.dysy.demo.jframe;

import javax.swing.JFrame;

import com.dysy.demo.beans.Account;
import com.dysy.demo.beans.Customer;

public class AccountOperationPanel extends JFrame{

	/**
	 * 
	 */
	private Account account;
	private Customer customer;
	private static final long serialVersionUID = 1L;
    
    public AccountOperationPanel(Account account,Customer customer) {
    	this.account = account;
    	this.customer = customer;
    }
    
    public void deleteAccount(Account account) {
    	
    }
    
    public void deleteAllAccount(Customer customer) {
    	
    }
    
    public void openAccount(Account account) {
    	
    }

}
