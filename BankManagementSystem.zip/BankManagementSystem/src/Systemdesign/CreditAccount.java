package Systemdesign;

import java.math.BigDecimal;

import systemdesignenum.AccountTypeEnum;
//The class of CreditAccount extends the shared similarities of an account and write its own attributes and methods.
public class CreditAccount extends Account {

    //card attribute
    private Long card;
    //constructor
    public CreditAccount(String accountNumber, BigDecimal balance, Long card) {
        super(accountNumber, balance);
        this.card = card;
    }
     //getters
    public Long getCard() {
        return card;
    }
    //override the abstract method from Account
    @Override
    public AccountTypeEnum getAccountType() {
        return AccountTypeEnum.credit;
    }

}

