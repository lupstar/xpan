package com.dysy.demo.beans;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

public class Account implements TransactionOperation {

	private String accountNumber;

	private BigDecimal balance;

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public void withdralAccount(Transaction trans) throws Exception {
		boolean checkOk = this.checkTransAmount(trans);
		if (checkOk) {
			List<TransTypeEnum> transTypeEnumList = this.getTransFunction();
			if(transTypeEnumList.contains(TransTypeEnum.withdrawal)) {
				
			}else {
				throw new Exception("不允许此交易");
			}
		}
	};

	public void depositAccount(Transaction trans) throws Exception {
		boolean checkOk = this.checkTransAmount(trans);
		if (checkOk) {
			List<TransTypeEnum> transTypeEnumList = this.getTransFunction();
			if(transTypeEnumList.contains(TransTypeEnum.deposit)) {
				
			}else {
				throw new Exception("不允许此交易");
			}
		}
	};

	public void transferAccount(Transaction trans) throws Exception {
		boolean checkOk = this.checkTransAmount(trans);
		if (checkOk) {
			List<TransTypeEnum> transTypeEnumList = this.getTransFunction();
			if(transTypeEnumList.contains(TransTypeEnum.transfer)) {
				
			}else {
				throw new Exception("不允许此交易");
			}
		}
	};

	public void useCard(Transaction trans) throws Exception {
		boolean checkOk = this.checkTransAmount(trans);
		if (checkOk) {
			List<TransTypeEnum> transTypeEnumList = this.getTransFunction();
			if(transTypeEnumList.contains(TransTypeEnum.card)) {
				
			}else {
				throw new Exception("不允许此交易");
			}
		}
	};

	public String getAccountType() {
		return "base";
	}

	public List<TransTypeEnum> getTransFunction() {
		return Arrays.asList(TransTypeEnum.values());
	}

	public boolean checkTransAmount(Transaction trans) {
		// 取款金额必须为负
		if (TransTypeEnum.withdrawal.getTransCode().equals(trans.getTransType().toString())) {
			if (trans.getAmount().compareTo(BigDecimal.ZERO) > 0) {
				return false;
			}
			// 当客户将钱存入账户时，存款的金额必须为正
		} else if (TransTypeEnum.deposit.getTransCode().equals(trans.getTransType().toString())) {
			if (trans.getAmount().compareTo(BigDecimal.ZERO) < 0) {
				return false;
			}
			// 账或刷卡交易金额可为正数或负数
		} else {
			return true;
		}
		return true;
	};
	
	

}
