package com.dysy.demo.beans;

import java.math.BigDecimal;

public interface CustomerOperation {

	 public void openAccount(AccountTypeEnum accountTypeEnum,BigDecimal openAmount) throws Exception;
	 
	 public void deleteAccount(Account account) throws Exception;
	 
	 public void deleteAllAccount(Customer customer) throws Exception;
}
