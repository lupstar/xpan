package com.work.beans.interfaces;

import java.math.BigDecimal;

public interface CustomerOperation {

	/**
	 * 用户单个账户开户
	 * @param accountTypeEnum
	 * @param openAmount
	 * @throws Exception
	 */
	 public void openAccount(AccountTypeEnum accountTypeEnum,BigDecimal openAmount) throws Exception;
	 
	 /**
	  * 注销单个账户
	  * @param account
	  * @throws Exception
	  */
	 public void deleteAccount(Account account) throws Exception;
	 
	 /**
	  * 注销某用户下的所有账户
	  * @param customer
	  * @throws Exception
	  */
	 public void deleteAllAccount(Customer customer) throws Exception;
}
