package panel;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Systemdesign.Account;
import Systemdesign.CreditAccount;
import Systemdesign.Customer;
import Systemdesign.DebitAccount;
import Systemdesign.SavingsAccount;
import fileOperation.FileReadAndWrite;
//This is a class used to creat GUI that displays the information of customers' accounts
public class CustomerPanel extends JFrame {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private JPanel contentPane;

    @SuppressWarnings({"rawtypes", "unchecked"})
    public CustomerPanel(Long queryCustId, String queryAccountNo) {
        //load data files
        List<Customer> customers = new ArrayList<>();
        try {
            FileReadAndWrite.loadData(customers);
        } catch (Exception e) {
            System.out.print(e.getMessage());
        }

        //总面板初始化 initialize the JFrame
        contentPane = new JPanel();
        setTitle("The information of customers and accounts");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 400);
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
        contentPane.setForeground(Color.LIGHT_GRAY);
        contentPane.setBackground(new Color(248, 248, 255));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setResizable(false);
        setContentPane(contentPane);
        //客户及账户查询面板初始化 initialize the querying panel of the customer and account
        final JPanel queryPanel = new JPanel();
        queryPanel.setBackground(new Color(248, 248, 255));
        contentPane.add(queryPanel);

        JLabel label = new JLabel("客户ID：");
        JComboBox cmb = new JComboBox();
        cmb.addItem("--请选择--");
        JLabel accountLabel = new JLabel("账户：");
        JComboBox accountCmb = new JComboBox();
        accountCmb.addItem("--请选择--");

        //查询面板加载组件
        queryPanel.add(label);
        if (queryCustId != null) {
            for (int i = 0; i < cmb.getItemCount(); i++) {
                String item = (String) cmb.getItemAt(i);
                if (item.indexOf(queryCustId.toString()) > 0) {
                    cmb.setSelectedIndex(i);
                    break;
                }
            }
        }
        queryPanel.add(cmb);

        queryPanel.add(accountLabel);
        if (queryAccountNo != null) {
            for (int i = 1; i < accountCmb.getItemCount(); i++) {
                String item = (String) accountCmb.getItemAt(i);
                String endNo = item.split("-")[1];
                if (queryAccountNo.endsWith(endNo)) {
                    accountCmb.setSelectedIndex(i);
                    break;
                }
            }
        }
        queryPanel.add(accountCmb);

        //客户信息面板初始化 initialize the information panel of customers
        final JPanel customerPanel = new JPanel();
        customerPanel.setBackground(new Color(248, 248, 255));
        customerPanel.setVisible(false);
        contentPane.add(customerPanel);

        JTextField txtfield1 = new JTextField(10);
        txtfield1.setEditable(false);
        JLabel label1 = new JLabel("Name：");
        customerPanel.add(label1);
        customerPanel.add(txtfield1);
        JLabel label2 = new JLabel("Customer ID：");
        JTextField txtfield2 = new JTextField(10);
        txtfield2.setEditable(false);
        customerPanel.add(label2);
        customerPanel.add(txtfield2);
        JTextField txtfield3 = new JTextField(10);
        txtfield3.setEditable(false);
        JLabel label3 = new JLabel("Birthdate：");
        customerPanel.add(label3);
        customerPanel.add(txtfield3);
        JTextField txtfield4 = new JTextField(10);
        txtfield4.setEditable(false);
        JLabel label4 = new JLabel("The number of accounts：");
        customerPanel.add(label4);
        customerPanel.add(txtfield4);

        //账户信息面板 initialze the panel of accounts' information
        final JPanel accountPanel = new JPanel();
        accountPanel.setBackground(new Color(248, 248, 255));
        accountPanel.setVisible(false);
        contentPane.add(accountPanel);

        JLabel label5 = new JLabel("Account number：");
        final JTextField txtfield5 = new JTextField(20);
        txtfield5.setEditable(false);
        accountPanel.add(label5);
        accountPanel.add(txtfield5);
        JLabel label6 = new JLabel("Balance：");
        JTextField txtfield6 = new JTextField(10);
        txtfield6.setEditable(false);
        accountPanel.add(label6);
        accountPanel.add(txtfield6);
        JLabel label7 = new JLabel("Card attribute：");
        JTextField txtfield7 = new JTextField(20);
        txtfield7.setEditable(false);
        label7.setVisible(false);
        txtfield7.setVisible(false);
        accountPanel.add(label7);
        accountPanel.add(txtfield7);
        JLabel label8 = new JLabel("Interest rate：");
        JTextField txtfield8 = new JTextField(10);
        txtfield8.setEditable(false);
        label7.setVisible(false);
        txtfield8.setVisible(false);
        accountPanel.add(label8);
        accountPanel.add(txtfield8);

        //客户Id下拉框数据加载 The combobox of customer Id
        for (int i = 0; i < customers.size(); i++) {
            Customer customer = customers.get(i);
            Long custId = customer.getCustId();
            String custName = customer.getCustName();
            cmb.addItem(custName + "(" + custId + ")");
        }

        //客户Id下拉框选中事件触发  trigger the actionlisterner when users choose customer id combobox
        cmb.addActionListener((ActionEvent e) -> {
            String custInfo = (String) cmb.getSelectedItem();
            //为选中提示选择用户
            if (custInfo == null || "--please select--".equals(custInfo)) {
                customerPanel.setVisible(false);
                accountPanel.setVisible(false);
                accountCmb.removeAllItems();
                accountCmb.addItem("--please select--");
                JOptionPane.showMessageDialog(null, "please select customer", "note", JOptionPane.ERROR_MESSAGE);
                return;
            }
            //选中展示客户面板并加载账户下拉框选项 The combobox of accounts information
            Long custId = Long.valueOf(custInfo.substring(custInfo.indexOf("(") + 1, custInfo.indexOf(")")));
            for (int i = 0; i < customers.size(); i++) {
                Customer customer = customers.get(i);
                if (customer.getCustId().compareTo(custId) == 0) {
                    txtfield1.setText(customer.getCustName());
                    txtfield2.setText(customer.getCustId().toString());
                    txtfield3.setText(customer.getBirthDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
                    txtfield4.setText(Integer.toString(customer.getAccountList().size()));
                    customerPanel.setVisible(true);
                    accountCmb.removeAllItems();
                    accountCmb.addItem("--please selecet--");
                    for (int j = 0; j < customer.getAccountList().size(); j++) {
                        Account account = customer.getAccountList().get(j);
                        String accountNumber = account.getAccountNumber();
                        String type1 = account.getAccountType().getAccountType();
                        accountCmb.addItem(type1 + " xxx-" + accountNumber.substring(accountNumber.length() - 4));
                    }
                    accountPanel.setVisible(false);
                }
            }
        });

        //账户下拉框触发事件：账户面板显示 trigger the actionlisterner when users choose account combobox
        accountCmb.addActionListener((ActionEvent e) -> {
            String custInfo = (String) cmb.getSelectedItem();
            String accountNumber = (String) accountCmb.getSelectedItem();
            if (accountNumber == null || "--please select--".equals(accountNumber)) {
                return;
            }
            Long custId = Long.valueOf(custInfo.substring(custInfo.indexOf("(") + 1, custInfo.indexOf(")")));
            String endAccount = accountNumber.split("-")[1];
            for (Customer customer : customers) {
                if (customer.getCustId().compareTo(custId) == 0) {
                    List<Account> accounts = customer.getAccountList();
                    for (Account account : accounts) {
                        if (account.getAccountNumber().endsWith(endAccount)) {
                            txtfield5.setText(account.getAccountNumber());
                            txtfield6.setText(account.getBalance().toString());
                            if (null != account.getAccountType()) {
                                switch (account.getAccountType()) {
                                    case credit:
                                        txtfield7.setText(((CreditAccount) account).getCard().toString());
                                        txtfield8.setText("");
                                        label7.setVisible(true);
                                        txtfield7.setVisible(true);
                                        label8.setVisible(false);
                                        txtfield8.setVisible(false);
                                        break;
                                    case debit:
                                        txtfield7.setText(((DebitAccount) account).getCard().toString());
                                        txtfield8.setText("");
                                        label7.setVisible(true);
                                        txtfield7.setVisible(true);
                                        label8.setVisible(false);
                                        txtfield8.setVisible(false);
                                        break;
                                    case savings:
                                        txtfield7.setText("");
                                        BigDecimal rate = ((SavingsAccount) account).getInterestRate();
                                        txtfield8.setText(rate == null ? "" : rate.toString());
                                        label7.setVisible(false);
                                        txtfield7.setVisible(false);
                                        label8.setVisible(true);
                                        txtfield8.setVisible(true);
                                        break;
                                    default:
                                        break;
                                }
                            }
                            accountPanel.setVisible(true);
                        }
                    }
                }
            }
        });

        //组装面板组件 organize components of panels
        GroupLayout gl_contentPane = new GroupLayout(contentPane);
        gl_contentPane.setHorizontalGroup(
                gl_contentPane.createParallelGroup(Alignment.LEADING)
                        .addGroup(gl_contentPane.createSequentialGroup()
                                .addGap(163)
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false))
                                .addContainerGap(166, Short.MAX_VALUE))
        );
        gl_contentPane.setVerticalGroup(
                gl_contentPane.createParallelGroup(Alignment.LEADING)
                        .addGroup(gl_contentPane.createSequentialGroup()
                                .addGap(54)
                                .addContainerGap(35, Short.MAX_VALUE))
        );

    }

}
