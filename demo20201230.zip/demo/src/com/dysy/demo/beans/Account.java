package com.dysy.demo.beans;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.dysy.demo.dataload.FileReaderAndWrite;

public class Account implements TransactionOperation {

	private String accountNumber;

	private BigDecimal balance;
	
	public Account(String accountNumber,BigDecimal balance) {
		this.accountNumber = accountNumber;
		this.balance = balance;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void withdralAccount(Transaction trans) throws Exception {
		this.checkTransAmount(trans);
		
		List<TransTypeEnum> transTypeEnumList = this.getTransFunction();
		if(transTypeEnumList.contains(TransTypeEnum.withdrawal)) {
			Customer customer = this.queryCustomerByAccountNumber(accountNumber);
			FileReaderAndWrite.writeAccount(this, customer.getCustId(), trans,null);
			FileReaderAndWrite.writeTransRecord(this, customer.getCustId(), trans);
		}else {
			throw new Exception("不允许此交易");
		}
	};

	public void depositAccount(Transaction trans) throws Exception {
		this.checkTransAmount(trans);
		
		List<TransTypeEnum> transTypeEnumList = this.getTransFunction();
		if(transTypeEnumList.contains(TransTypeEnum.deposit)) {
			Customer customer = this.queryCustomerByAccountNumber(accountNumber);
			FileReaderAndWrite.writeAccount(this, customer.getCustId(), trans,null);
			FileReaderAndWrite.writeTransRecord(this, customer.getCustId(), trans);
		}else {
			throw new Exception("不允许此交易");
		}
	};

	public void transferAccount(Transaction trans) throws Exception {
		this.checkTransAmount(trans);

		List<TransTypeEnum> transTypeEnumList = this.getTransFunction();
		if(transTypeEnumList.contains(TransTypeEnum.transfer)) {
			Customer customer = this.queryCustomerByAccountNumber(accountNumber);
			FileReaderAndWrite.writeAccount(this, customer.getCustId(), trans,null);
			FileReaderAndWrite.writeTransRecord(this, customer.getCustId(), trans);
		}else {
			throw new Exception("不允许此交易");
		}
	};

	public void useCard(Transaction trans) throws Exception {
		this.checkTransAmount(trans);
		
		List<TransTypeEnum> transTypeEnumList = this.getTransFunction();
		if(transTypeEnumList.contains(TransTypeEnum.card)) {
			Customer customer = this.queryCustomerByAccountNumber(accountNumber);
			FileReaderAndWrite.writeAccount(this, customer.getCustId(), trans,null);
			FileReaderAndWrite.writeTransRecord(this, customer.getCustId(), trans);
		}else {
			throw new Exception("不允许此交易");
		}
	};

	public String getAccountType() {
		return "base";
	}

	public List<TransTypeEnum> getTransFunction() {
		return Arrays.asList(TransTypeEnum.values());
	}

	public void checkTransAmount(Transaction trans) throws Exception {
		// 取款金额必须为负
		if (TransTypeEnum.withdrawal.getTransCode().equals(trans.getTransType().getTransCode())) {
			if (trans.getAmount().compareTo(BigDecimal.ZERO) > 0) {
				throw new Exception("取款金额不能为正数");
			}
			// 当客户将钱存入账户时，存款的金额必须为正
		} else if (TransTypeEnum.deposit.getTransCode().equals(trans.getTransType().getTransCode())) {
			if (trans.getAmount().compareTo(BigDecimal.ZERO) < 0) {
				throw new Exception("存款金额不能为负数");
			}
			// 账或刷卡交易金额可为正数或负数
		} else {
			return;
		}
	};
	
	public Customer queryCustomerByAccountNumber(String accountNumber) throws Exception {
		// 取款金额必须为负
		List<Customer> customers = new ArrayList<Customer>();
		FileReaderAndWrite.loadData(customers);
		for(Customer customer:customers) {
			for(Account account:customer.getAccountList()) {
				if(account.getAccountNumber().equals(accountNumber)) {
					return customer;
				}
			}
		}
		return null;
	};
	
	

}
