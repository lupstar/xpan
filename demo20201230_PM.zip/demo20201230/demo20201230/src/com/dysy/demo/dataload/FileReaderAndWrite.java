package com.dysy.demo.dataload;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.dysy.demo.beans.Account;
import com.dysy.demo.beans.CreditAccount;
import com.dysy.demo.beans.Customer;
import com.dysy.demo.beans.DebitAccount;
import com.dysy.demo.beans.SavingsAccount;
import com.dysy.demo.beans.Transaction;


public class FileReaderAndWrite {
    
	/**
	 * 读取文件，组装所有的用户及账户信息
	 * @param customers
	 * @throws Exception
	 */
	public static void loadData(List<Customer> customers) throws Exception {
		FileReaderAndWrite.loadCustomers(customers);
        FileReaderAndWrite.loadCreditAccounts(customers);
        FileReaderAndWrite.loadDebitAccounts(customers);
        FileReaderAndWrite.loadSavingsAccounts(customers);
	}
	
	/**
	 * 读取用户文件信息
	 * @param customers
	 * @throws Exception
	 */
    public static void loadCustomers(List<Customer> customers) throws Exception {
        String path = new File("file/database/customers.csv").getCanonicalPath();
        File file = new File(path);
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new java.io.FileReader(file));
            String strLine = null;
            while(null != (strLine = bufferedReader.readLine())){
                String[] dataLine = strLine.split(",");
                Customer customer = new Customer(dataLine[0],Long.valueOf(dataLine[1]),LocalDate.parse(dataLine[2]),new ArrayList<Account>());
                customers.add(customer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try{
                if(bufferedReader!=null){
                    bufferedReader.close();
                }
            }catch (IOException ioe){
                ioe.printStackTrace();
            }
        }
    }
    
    /**
	 * 读取借方账户信息
	 * @param customers
	 * @throws Exception
	 */
    public static void loadCreditAccounts(List<Customer> customers) throws Exception {
        String path = new File("file/database/credit_accounts.csv").getCanonicalPath();
        File file = new File(path);
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new java.io.FileReader(file));
            String strLine = null;
            while(null != (strLine = bufferedReader.readLine())){
                String[] dataLine = strLine.split(",");
                String custId = dataLine[0];
                for(Customer customer:customers){
                	if(customer.getCustId().toString().equals(custId)) {
                		CreditAccount creditAccount = new CreditAccount(dataLine[1],new BigDecimal(dataLine[2]),Long.valueOf(dataLine[3]));
                        List<Account> accounts = customer.getAccountList();
                        if(accounts.size()<5) {
                        	accounts.add(creditAccount);
                        }else {
                        	throw new Exception("account lager than five...");
                        }
                	}
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try{
                if(bufferedReader!=null){
                    bufferedReader.close();
                }
            }catch (IOException ioe){
                ioe.printStackTrace();
            }
        }
    }
    
    /**
	 * 读取贷方账户信息
	 * @param customers
	 * @throws Exception
	 */
    public static void loadDebitAccounts(List<Customer> customers) throws Exception {
        String path = new File("file/database/debit_accounts.csv").getCanonicalPath();
        File file = new File(path);
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new java.io.FileReader(file));
            String strLine = null;
            while(null != (strLine = bufferedReader.readLine())){
                String[] dataLine = strLine.split(",");
                String custId = dataLine[0];
                for(Customer customer:customers){
                	if(customer.getCustId().toString().equals(custId)) {
                		DebitAccount debitAccount = new DebitAccount(dataLine[1],new BigDecimal(dataLine[2]),Long.valueOf(dataLine[3]));
                		List<Account> accounts = customer.getAccountList();
                        if(accounts.size()<5) {
                        	accounts.add(debitAccount);
                        }else {
                        	throw new Exception("account lager than five...");
                        }
                	}
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try{
                if(bufferedReader!=null){
                    bufferedReader.close();
                }
            }catch (IOException ioe){
                ioe.printStackTrace();
            }
        }
    }
    
    /**
	 * 读取储蓄账户信息
	 * @param customers
	 * @throws Exception
	 */
    public static void loadSavingsAccounts(List<Customer> customers) throws Exception {
        String path = new File("file/database/savings_accounts.csv").getCanonicalPath();
        File file = new File(path);
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new java.io.FileReader(file));
            String strLine = null;
            while(null != (strLine = bufferedReader.readLine())){
                String[] dataLine = strLine.split(",");
                String custId = dataLine[0];
                for(Customer customer:customers){
                	if(customer.getCustId().toString().equals(custId)) {
                		SavingsAccount savingsAccount = new SavingsAccount(dataLine[1],new BigDecimal(dataLine[2]),null);
                		List<Account> accounts = customer.getAccountList();
                        if(accounts.size()<5) {
                        	accounts.add(savingsAccount);
                        }else {
                        	throw new Exception("account lager than five...");
                        }
                                        	}
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try{
                if(bufferedReader!=null){
                    bufferedReader.close();
                }
            }catch (IOException ioe){
                ioe.printStackTrace();
            }
        }
    }
    
    /**
	 * 写入账户更新修改删除等操作（开户，销户，提款，取款，转账，刷卡等数据变更）
	 * @param customers
	 * @throws Exception
	 */
    public static void writeAccount(Account account,Long custId,Transaction trans,String accountOperate) throws Exception {
    	String path = "";
        String appendLine="";
        BigDecimal currentBalance = account.getBalance().add(trans==null?BigDecimal.ZERO:trans.getAmount());
    	if(account instanceof com.dysy.demo.beans.CreditAccount) {
    		path = new File("file/database/credit_accounts.csv").getCanonicalPath();
    		appendLine = custId+","+account.getAccountNumber()+","+currentBalance+","+((CreditAccount) account).getCard() +"\n";
    	}else if(account instanceof com.dysy.demo.beans.DebitAccount) {
    		path = new File("file/database/debit_accounts.csv").getCanonicalPath();
    		appendLine = custId+","+account.getAccountNumber()+","+currentBalance+","+((DebitAccount) account).getCard() +"\n";
    	}else if(account instanceof com.dysy.demo.beans.SavingsAccount) {
    		path = new File("file/database/savings_accounts.csv").getCanonicalPath();
    		appendLine = custId+","+account.getAccountNumber()+","+currentBalance+"\n";
    	}
        File file = new File(path);
        BufferedReader bufferedReader = null;
        FileWriter fw= null;
        try {
        	StringBuffer content = new StringBuffer("");
            if("add".equals(accountOperate)) {
            	fw = new FileWriter(path,true);
            	content.append(appendLine);
            }else {
                bufferedReader = new BufferedReader(new java.io.FileReader(file));
                String strLine = null;
                while(null != (strLine = bufferedReader.readLine())){
                    String[] dataLine = strLine.split(",");
                    String flieCustId = dataLine[0];
                    if(flieCustId.equals(custId.toString())&&account.getAccountNumber().equals(dataLine[1])) {
                    	if("del".equals(accountOperate)) {
                    		continue;
                    	} else if(trans!=null){
                    		content.append(appendLine);
                    		continue;
                    	}
                    }
                    content.append(strLine+"\n");
                }
            	fw = new FileWriter(path);
            }
            fw.write(content.toString());
            fw.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try{
                if(bufferedReader!=null){
                    bufferedReader.close();
                }
                if(fw!=null) {
                	fw.close();
                }
            }catch (IOException ioe){
                ioe.printStackTrace();
            }
        }
    }
    
    /**
     * 写入事务操作日志
     * @param account
     * @param custId
     * @param trans
     * @throws Exception
     */
    public static void writeTransRecord(Account account,Long custId,Transaction trans) throws Exception {
    	String path = "";
        String appendLine="";
        BigDecimal currentBalance = account.getBalance().add(trans==null?BigDecimal.ZERO:trans.getAmount());
    	
    	path = new File("file/database").getCanonicalPath();
    	appendLine = trans.getTransId()+","+custId+","+account.getAccountNumber()
    				+","+account.getBalance()+","+currentBalance
    				+","+trans.getAmount()+","+trans.getTransType().getName()
    				+","+LocalDateTime.now()
    				+"\n";
 
        FileWriter fw=null;
        try {
        	File file = new File(path+"/transation.csv");
            if(!file.exists()) {
            	file.createNewFile();
            }
        	fw = new FileWriter(file, true);     
        	fw.write(appendLine);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try{
                if(fw!=null) {
                	fw.close();
                }
            }catch (IOException ioe){
                ioe.printStackTrace();
            }
        }
    }
    
    /**
     * 获取并保存当前key
     * @param code
     * @return
     * @throws Exception
     */
    public static String getCurrentKeys(String code) throws Exception {
    	String key = null;
    	String path = "";
        String appendLine="";
        
    	path = new File("file/database/key.txt").getCanonicalPath();
        File file = new File(path);
        BufferedReader bufferedReader = null;
        FileWriter fw= null;
        try {
        	StringBuffer content = new StringBuffer("");
            
            bufferedReader = new BufferedReader(new java.io.FileReader(file));
            String strLine = null;
            while(null != (strLine = bufferedReader.readLine())){
                if(strLine.indexOf(code)>-1) {
                	String str[] = strLine.split("=");
                	key = (Long.valueOf(str[1])+1)+"";
                	appendLine = str[0]+"="+ key+"\n";
                	content.append(appendLine);
                }else {
                	content.append(strLine).append("\n");
                }
            }
            fw = new FileWriter(path);
            fw.write(content.toString());
            fw.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try{
                if(bufferedReader!=null){
                    bufferedReader.close();
                }
                if(fw!=null) {
                	fw.close();
                }
            }catch (IOException ioe){
                ioe.printStackTrace();
            }
        }
        return key;
    }

}
