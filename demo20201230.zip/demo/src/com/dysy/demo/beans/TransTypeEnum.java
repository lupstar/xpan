package com.dysy.demo.beans;


public enum TransTypeEnum {

    withdrawal("C01","提款"),

    deposit("C02","存款"),

    transfer("C03","转账"),

    card("C04","刷卡");

    private String transCode;

    private String name;

    public String getTransCode() {
        return transCode;
    }

    public String getName() {
        return name;
    }

    TransTypeEnum(String transCode, String name){
        this.transCode = transCode;
        this.name = name;
    }
    
    public static TransTypeEnum getTransTypeEnumByName(String name) {
    	for(TransTypeEnum transTypeEnum:TransTypeEnum.values()) {
    		if(transTypeEnum.getName().equals(name)) {
    			return transTypeEnum;
    		}
    	}
    	return null;
    }
    
    public static TransTypeEnum getTransTypeEnumByCode(String code) {
    	for(TransTypeEnum transTypeEnum:TransTypeEnum.values()) {
    		if(transTypeEnum.getTransCode().equals(code)) {
    			return transTypeEnum;
    		}
    	}
    	return null;
    }
}
