package com.dysy.demo;
import java.io.*;
import java.util.List;

public class UserFile {
	
	/**
	 * 使用文件的序列化来保存用户的信息
	 * @param info
	 */
	public void saveFile(List<UserInfo> info) {
		FileOutputStream fos;//文件输出流
		ObjectOutputStream oos;//对象输出流
		String filePath = System.getProperty("user.dir");//获取当前项目的路径
		filePath+="\\src\\com\\dysy\\demo\\UserInfo.txt";
		
		File userFile = new File(filePath);
		
		try {
			userFile.createNewFile();
			fos = new FileOutputStream(userFile);//构建文件输出流
			oos = new ObjectOutputStream(fos);//构建对象输出流装饰文件输出流
			oos.writeObject(info);//存入对象
			oos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 使用反序列化读取用户的信息，并返回用户信息
	 * @return info
	 */
	public Object printFile() {
		FileInputStream fis = null;//文件输入流
		ObjectInputStream ois = null;//对象输入流
		String filePath = System.getProperty("user.dir");//获取当前项目的路径
		filePath+="\\src\\com\\dysy\\demo\\UserInfo.txt";
		
		Object info = null;
		
		try {
			fis = new FileInputStream(new File(filePath));//构建文件输入流
			ois = new ObjectInputStream(fis);//构建对象输入流装输入流饰文件
			info = ois.readObject();//反序列化恢复对象
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				ois.close();
				fis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return info;
	}
}